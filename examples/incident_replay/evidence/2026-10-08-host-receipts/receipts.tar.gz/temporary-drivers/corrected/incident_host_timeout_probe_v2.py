"""Run one corrected native host-timeout fault probe without rerunning normal pairs."""

import argparse
import asyncio
from datetime import UTC, datetime
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import sys
import time

ROOT = Path('/Users/xiangfu/.codex/worktrees/6789/mcp-pinot-incidents')
sys.path.insert(0, str(ROOT))
from examples.incident_replay import fixture, live, runner

JAVA = '/Library/Java/JavaVirtualMachines/temurin-25.jdk/Contents/Home/bin/java'
JAR = Path('/Users/xiangfu/.m2/repository/org/apache/pinot/pinot-distribution/1.5.1/pinot-distribution-1.5.1-shaded.jar')
PROXY = Path('/tmp/incident_delayed_query_proxy_v2.py')
FROZEN = '85ac85eefc65e3ef4538319224a9e15e65c0a82f'
PORTS = (2123,6000,7050,7051,7052,7100,7101,7102,7500,7501,7502,8000,8010,8080,9000)


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def process_state(pid):
    result = subprocess.run(['ps','-p',str(pid),'-o','stat='], capture_output=True, text=True, shell=False, timeout=5)
    state = result.stdout.strip()
    return {'pid':pid,'state':state or 'absent','running':bool(state) and not state.startswith('Z')}


def group_state(pgid):
    result = subprocess.run(['pgrep','-g',str(pgid),'-l'], capture_output=True, text=True, shell=False, timeout=5)
    if result.returncode not in (0,1):
        raise RuntimeError('Owned group status could not be read.')
    return {'pgid':pgid,'remaining_processes':result.stdout.strip(),'empty':result.returncode == 1}


def probe(output, seed, native_pgid, drivers, source):
    case = json.loads((seed / 'public.json').read_text())['cases'][0]
    directory = output / 'model/0'
    directory.parent.mkdir()
    args = argparse.Namespace(dataset=seed,broker='http://127.0.0.1:8000',controller='http://127.0.0.1:9000',codex=runner.executable_path('codex',program='codex'),cli_defaults=True,timeout=30,mode='model',planned_collection=True,host_telemetry=True)
    original_popen = runner.subprocess.Popen
    changes = []
    cli_process = {}
    prefix = 'mcp_servers.incident_reader.args='

    def intercept(argv,*popen_args,**popen_kwargs):
        if not isinstance(argv,list) or len(argv) < 2 or Path(argv[0]).name != 'codex' or argv[1] != 'exec':
            return original_popen(argv,*popen_args,**popen_kwargs)
        positions = [index for index,value in enumerate(argv) if isinstance(value,str) and value.startswith(prefix)]
        if len(positions) != 1:
            raise ValueError('Expected one original incident proxy config.')
        index = positions[0]
        old = json.loads(argv[index][len(prefix):])
        if not isinstance(old,list) or not old or old[0] != str(ROOT / 'examples/incident_replay/model.py'):
            raise ValueError('Unexpected original model proxy path.')
        new = [str(PROXY),*old[1:]]
        changed = list(argv)
        changed[index] = prefix + json.dumps(new)
        changes.append({'original_driver':old[0],'replacement_driver':new[0],'all_other_cli_arguments_identical':all(before == after for position,(before,after) in enumerate(zip(argv,changed)) if position != index),'remaining_proxy_arguments_identical':old[1:] == new[1:]})
        process = original_popen(changed,*popen_args,**popen_kwargs)
        cli_process.update({'pid':process.pid,'pgid':os.getpgid(process.pid)})
        return process

    runner.subprocess.Popen = intercept
    try:
        prediction = asyncio.run(runner._prediction(args,case,directory))
    finally:
        runner.subprocess.Popen = original_popen
    write(directory / 'prediction.json',prediction)
    cli_process.update({'exit_code':prediction.get('exit_code'),'timed_out':prediction.get('timed_out')})
    marker_path = directory / 'delayed-baseline-request.json'
    proxy_path = directory / 'delayed-proxy-runtime.json'
    proxy_runtime = json.loads(proxy_path.read_text()) if proxy_path.is_file() else {}
    cleanup_started = time.monotonic()
    states = []
    if proxy_runtime:
        deadline = time.monotonic() + 25
        while True:
            states = [process_state(proxy_runtime[key]) for key in ('proxy_pid','model_proxy_pid')]
            if not any(value['running'] for value in states) or time.monotonic() >= deadline:
                break
            time.sleep(0.1)
        proxy_runtime = json.loads(proxy_path.read_text())
    marker = json.loads(marker_path.read_text()) if marker_path.is_file() else None
    audit_path = directory / 'calls.jsonl'
    audit = [json.loads(line) for line in audit_path.read_text().splitlines()] if audit_path.is_file() else []
    audit_hash = digest(audit_path) if audit_path.is_file() else 'UNKNOWN'
    marker_hash = digest(marker_path) if marker_path.is_file() else 'UNKNOWN'
    owned_group = group_state(proxy_runtime['proxy_pgid']) if proxy_runtime else {'empty':False}
    telemetry = prediction.get('host_telemetry',{})
    tokens = telemetry.get('token_usage',{})
    latest = tokens.get('latest_total',{})
    positive = isinstance(latest,dict) and type(latest.get('input_tokens')) is int and latest['input_tokens'] > 0 and type(latest.get('output_tokens')) is int and latest['output_tokens'] > 0
    checks = {
        'exactly_one_config_interception':len(changes) == 1 and changes[0]['all_other_cli_arguments_identical'] and changes[0]['remaining_proxy_arguments_identical'],
        'actual_host_deadline_observed':prediction.get('timed_out') is True,
        'original_finish_not_verified':prediction.get('verified_finish') is False,
        'no_fabricated_finish':prediction.get('raw_finish') is None,
        'completed_cli_usage_remains_unknown':prediction.get('model_usage') == 'UNKNOWN',
        'no_completed_provider_receipt':'provider_receipt' not in prediction,
        'owned_partial_snapshot_observed':positive and tokens.get('snapshot_count',0) > 0,
        'partial_snapshot_not_complete_usage':tokens.get('complete') is False,
        'no_completed_turn_claim':telemetry.get('completion',{}).get('cli_completed_turn_observed') is False,
        'owned_session_archived_and_preserved':prediction.get('host_session_archived') is True and prediction.get('host_session_bytes_preserved') is True,
        'no_late_baseline_forwarding':isinstance(marker,dict) and marker.get('forwarded_to_original_driver') is False and marker.get('cancelled_during_delay') is True,
        'baseline_not_admitted_as_native_sql':not any(call.get('tool') == 'query_incident' and call.get('args',{}).get('kind') == 'baseline' for call in audit),
        'original_prediction_calls_equal_final_closed_audit':prediction.get('calls') == audit,
        'stdin_eof_observed':proxy_runtime.get('stdin_eof_observed') is True,
        'original_model_proxy_cleanup_not_escalated':proxy_runtime.get('cleanup_escalated') is False,
        'owned_delayed_children_stopped':bool(states) and all(not value['running'] for value in states),
        'owned_mcp_group_empty':owned_group.get('empty') is True,
        'owned_cli_process_stopped':bool(cli_process) and not process_state(cli_process['pid'])['running'],
        'native_group_separate_from_cli_and_mcp':bool(cli_process) and bool(proxy_runtime) and native_pgid not in (cli_process['pgid'],proxy_runtime['proxy_pgid']),
        'source_unchanged':live.source_hashes(ROOT) == source,
    }
    driver_receipt = {'temporary_drivers':drivers,'actual_interception_count':len(changes),'cli_invocation_changes':changes,'cli_process':cli_process,'mcp_group_is_separate_from_cli':bool(proxy_runtime) and proxy_runtime['proxy_pgid'] != cli_process.get('pgid'),'cleanup_wait_ms':(time.monotonic()-cleanup_started)*1000,'owned_child_process_states':states,'owned_mcp_group_state':owned_group}
    write(output / 'temporary-driver.json',driver_receipt)
    report = {'schema_version':1,'scope':'Corrected standalone host-timeout cleanup probe; original combined v1 failure and all 18 normal pairs remain unchanged.','excluded_from_model_accuracy':True,'excluded_from_collection_comparison':True,'case_id':case['case_id'],'dataset_seed':450,'host_deadline_seconds':30,'injected_baseline_delay_seconds':60,'prediction':prediction,'checks':checks,'all_passed':all(checks.values()),'probe_complete':True,'source_sha256':source,'source_sha256_end':live.source_hashes(ROOT),'source_unchanged':checks['source_unchanged'],'git':live.git_identity(ROOT),'temporary_drivers':drivers,'delayed_baseline_request':marker or 'NOT_OBSERVED','delayed_proxy_runtime':proxy_runtime or 'NOT_OBSERVED','owned_child_process_states':states,'owned_mcp_group_state':owned_group,'audit_sha256_after_cleanup':audit_hash,'marker_sha256_after_cleanup':marker_hash,'finished_at':datetime.now(UTC).isoformat()}
    write(output / 'host-timeout-probe.json',report)
    print(json.dumps({'stage':'standalone_timeout_cleanup_probe','all_passed':report['all_passed'],'checks':checks}),flush=True)
    if not report['all_passed']:
        raise RuntimeError('Standalone timeout cleanup validation failed; all artifacts retained, no rerun.')
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    if output != ROOT / 'examples/incident_replay/output/host-timeout-cleanup-v2' or output.exists():
        parser.error('Use the new exact owned host-timeout-cleanup-v2 output directory.')
    identity = live.git_identity(ROOT)
    if identity != {'head':FROZEN,'dirty':False}:
        parser.error('Require the exact clean frozen source commit.')
    java_version = subprocess.check_output([JAVA,'-version'],stderr=subprocess.STDOUT,text=True,shell=False)
    match = re.search(r'version "(\d+)',java_version)
    if not match or int(match[1]) < 25 or not JAR.is_file():
        parser.error('Require explicit JDK25+ and the existing native JAR.')
    for port in PORTS:
        with socket.socket() as sock:
            try:sock.bind(('127.0.0.1',port))
            except OSError as error:parser.error(f'Port {port} is occupied: {error}')
    output.mkdir(parents=True)
    source = live.source_hashes(ROOT)
    drivers = {str(path):digest(path) for path in (Path(__file__).resolve(),PROXY)}
    dataset = output / 'dataset'
    fixture.generate(dataset,seeds=1,start_seed=450,extended_cases=True)
    runtime = {'scope':'Standalone intentional host-timeout cleanup fault probe, excluded from all normal paired quality/latency/token totals.','git':identity,'fixture_suite':'extended','host_telemetry':True,'source_sha256':source,'started_at':datetime.now(UTC).isoformat(),'jar':str(JAR),'jar_sha256':digest(JAR),'java_version':java_version,'temporary_drivers':drivers,'evaluation_complete':False,'evaluation_valid':False}
    write(output / 'runtime.json',runtime)
    native_data = output / 'native-data'
    native_data.mkdir()
    command = [JAVA,'-Xmx2g','--enable-native-access=ALL-UNNAMED']
    for package in ('java.nio','sun.nio.ch','java.lang','java.util','java.lang.reflect','jdk.internal.misc'):
        command.append(f'--add-opens=java.base/{package}=ALL-UNNAMED')
    command += ['-Dio.netty.tryReflectionSetAccessible=true','-Dio.grpc.netty.shaded.io.netty.tryReflectionSetAccessible=true',f'-Djava.io.tmpdir={native_data}','-cp',str(JAR),'org.apache.pinot.tools.admin.PinotAdministrator','QuickStart','-type','BATCH','-tmpDir',str(native_data),'-bootstrapTableDir',str(sorted((dataset/'fixtures').iterdir())[0])]
    log_path = output / 'quickstart.log'
    with log_path.open('w') as log:
        native = subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,shell=False)
        runtime.update(owned_pid=native.pid,native_pgid=os.getpgid(native.pid))
        write(output / 'runtime.json',runtime)
        print(json.dumps({'stage':'owned_native_startup','owned_pid':native.pid,'output':str(output)}),flush=True)
        try:
            deadline = time.monotonic()+300
            while 'Quick start setup complete' not in log_path.read_text(errors='replace'):
                if native.poll() is not None or time.monotonic() >= deadline:
                    raise RuntimeError('Owned native startup failed; original log retained.')
                time.sleep(1)
            seed = dataset / 'seed_450'
            with (output/'parity-stdout.log').open('w') as stdout,(output/'parity-stderr.log').open('w') as stderr:
                subprocess.run([sys.executable,str(ROOT/'examples/incident_replay/load.py'),'--dataset',str(seed),'--verify-only','--broker','http://127.0.0.1:8000','--controller','http://127.0.0.1:9000','--output',str(output/'parity.json')],stdout=stdout,stderr=stderr,check=True,shell=False)
            runtime['parity'] = json.loads((output/'parity.json').read_text())
            print(json.dumps({'stage':'full_row_parity','rows':runtime['parity']['native_rows'],'passed':runtime['parity']['full_row_parity']}),flush=True)
            report = probe(output,seed,runtime['native_pgid'],drivers,source)
            runtime['evaluation_complete'] = report['all_passed']
        except Exception as error:
            runtime['failure'] = {'error_type':type(error).__name__,'detail':str(error)[:512]}
            raise
        finally:
            if native.poll() is None:
                native.terminate()
                try:native.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    native.kill()
                    native.wait(timeout=10)
            runtime['native_exit_code'] = native.returncode
            runtime['owned_process_stopped'] = native.poll() is not None
            runtime['source_sha256_end'] = live.source_hashes(ROOT)
            runtime['source_unchanged'] = runtime['source_sha256_end'] == source
            runtime['temporary_drivers_end'] = {path:digest(Path(path)) for path in drivers}
            runtime['temporary_drivers_unchanged'] = runtime['temporary_drivers_end'] == drivers
            runtime['stopped_at'] = datetime.now(UTC).isoformat()
            runtime['evaluation_valid'] = runtime['evaluation_complete'] and runtime['source_unchanged'] and runtime['temporary_drivers_unchanged'] and runtime['owned_process_stopped']
            if (output/'model/0/calls.jsonl').is_file() and (output/'host-timeout-probe.json').is_file():
                stored = json.loads((output/'host-timeout-probe.json').read_text())
                runtime['timeout_audit_stable_after_native_cleanup'] = stored['audit_sha256_after_cleanup'] == digest(output/'model/0/calls.jsonl')
                runtime['timeout_marker_stable_after_native_cleanup'] = stored['marker_sha256_after_cleanup'] == digest(output/'model/0/delayed-baseline-request.json')
                runtime['evaluation_valid'] = runtime['evaluation_valid'] and runtime['timeout_audit_stable_after_native_cleanup'] and runtime['timeout_marker_stable_after_native_cleanup']
            write(output/'runtime.json',runtime)
            print(json.dumps({'stage':'owned_cleanup','native_stopped':runtime['owned_process_stopped'],'source_unchanged':runtime['source_unchanged'],'evaluation_valid':runtime['evaluation_valid']}),flush=True)
            if not runtime['evaluation_valid'] and 'failure' not in runtime:
                raise RuntimeError('Standalone probe cleanup/source receipts invalid; artifacts retained.')


if __name__ == '__main__':
    main()
