"""Transparent stdio proxy that delays one real baseline request for a fault probe."""

from datetime import UTC, datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from threading import Thread
import time

ROOT = Path('/Users/xiangfu/.codex/worktrees/6789/mcp-pinot-incidents')
MODEL = ROOT / 'examples/incident_replay/model.py'
DELAY_SECONDS = 60


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def main():
    arguments = sys.argv[1:]
    if arguments.count('--audit') != 1:
        raise ValueError('Expected exactly one literal audit path.')
    audit = Path(arguments[arguments.index('--audit') + 1]).resolve()
    if not audit.is_relative_to(ROOT / 'examples/incident_replay/output') or audit.name != 'calls.jsonl' or audit.parent.name != '0' or audit.parent.parent.name != 'host-timeout-probe':
        raise ValueError('Only the owned ignored host-timeout audit directory is allowed.')
    runtime_path = audit.with_name('delayed-proxy-runtime.json')
    marker_path = audit.with_name('delayed-baseline-request.json')
    child = subprocess.Popen(
        [sys.executable, str(MODEL), *arguments],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=None,
        shell=False,
        # Inherit the CLI process group; its host deadline cancels only that group.
        start_new_session=False,
    )
    if child.stdin is None or child.stdout is None:
        raise RuntimeError('Owned original model proxy pipes are unavailable.')
    runtime = {
        'scope': 'one intentional delayed-baseline host deadline probe',
        'proxy_pid': os.getpid(),
        'proxy_pgid': os.getpgrp(),
        'model_proxy_pid': child.pid,
        'model_proxy_pgid': os.getpgid(child.pid),
        'inherited_process_group': os.getpgrp() == os.getpgid(child.pid),
        'original_driver': str(MODEL),
        'original_driver_sha256': hashlib.sha256(MODEL.read_bytes()).hexdigest(),
        'delay_seconds': DELAY_SECONDS,
        'started_at': datetime.now(UTC).isoformat(),
        'baseline_delayed': False,
    }
    write(runtime_path, runtime)

    def forward_stdout():
        # Retain the original driver's bytes, including spacing and newlines.
        for line in child.stdout:
            sys.stdout.buffer.write(line)
            sys.stdout.buffer.flush()

    reader = Thread(target=forward_stdout, daemon=True)
    reader.start()
    delayed = False
    try:
        for line in sys.stdin.buffer:
            request = json.loads(line)
            params = request.get('params', {})
            arguments_value = params.get('arguments', {}) if isinstance(params, dict) else {}
            if (
                not delayed
                and request.get('method') == 'tools/call'
                and isinstance(params, dict)
                and params.get('name') == 'query_incident'
                and isinstance(arguments_value, dict)
                and arguments_value.get('kind') == 'baseline'
            ):
                delayed = True
                runtime['baseline_delayed'] = True
                write(runtime_path, runtime)
                marker = {
                    'scope': 'first actual baseline request held before original MCP admission',
                    'tool': 'query_incident',
                    'kind': 'baseline',
                    'request_id': request.get('id'),
                    'received_at': datetime.now(UTC).isoformat(),
                    'delay_seconds': DELAY_SECONDS,
                    'forwarded_to_original_driver': False,
                    'forwarded_at': None,
                }
                write(marker_path, marker)
                time.sleep(DELAY_SECONDS)
                child.stdin.write(line)
                child.stdin.flush()
                marker['forwarded_to_original_driver'] = True
                marker['forwarded_at'] = datetime.now(UTC).isoformat()
                write(marker_path, marker)
                continue
            child.stdin.write(line)
            child.stdin.flush()
    finally:
        child.stdin.close()
        reader.join(timeout=1)
        if child.poll() is None:
            child.terminate()
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=5)
        runtime['owned_original_driver_exit_code'] = child.returncode
        runtime['finished_at'] = datetime.now(UTC).isoformat()
        write(runtime_path, runtime)


if __name__ == '__main__':
    main()
