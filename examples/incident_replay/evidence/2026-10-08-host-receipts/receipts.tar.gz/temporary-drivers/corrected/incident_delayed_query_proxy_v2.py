"""Hold one baseline transparently, but cancel its admission immediately on host EOF."""

from datetime import UTC, datetime
import hashlib
import json
import os
from pathlib import Path
from queue import Queue
import subprocess
import sys
from threading import Event, Thread

ROOT = Path('/Users/xiangfu/.codex/worktrees/6789/mcp-pinot-incidents')
MODEL = ROOT / 'examples/incident_replay/model.py'
DELAY_SECONDS = 60


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def main():
    arguments = sys.argv[1:]
    if arguments.count('--audit') != 1:
        raise ValueError('Expected one original literal audit path.')
    audit = Path(arguments[arguments.index('--audit') + 1]).resolve()
    if not audit.is_relative_to(ROOT / 'examples/incident_replay/output/host-timeout-cleanup-v2/model/0') or audit.name != 'calls.jsonl':
        raise ValueError('Only the new owned fault-probe audit directory is allowed.')
    runtime_path = audit.with_name('delayed-proxy-runtime.json')
    marker_path = audit.with_name('delayed-baseline-request.json')
    child = subprocess.Popen([sys.executable, str(MODEL), *arguments], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=None, shell=False, start_new_session=False)
    if child.stdin is None or child.stdout is None:
        raise RuntimeError('Owned original driver pipes are unavailable.')
    runtime = {
        'scope': 'corrected cancellable delayed-baseline fault injector only',
        'proxy_pid': os.getpid(), 'proxy_pgid': os.getpgrp(),
        'model_proxy_pid': child.pid, 'model_proxy_pgid': os.getpgid(child.pid),
        'child_inherits_proxy_group': os.getpgrp() == os.getpgid(child.pid),
        'original_driver': str(MODEL), 'original_driver_sha256': hashlib.sha256(MODEL.read_bytes()).hexdigest(),
        'delay_seconds': DELAY_SECONDS, 'started_at': datetime.now(UTC).isoformat(),
        'stdin_eof_observed': False, 'baseline_delayed': False, 'cleanup_escalated': False,
    }
    write(runtime_path, runtime)
    pending = Queue()
    eof = Event()
    output_closed = Event()

    def read_stdin():
        try:
            for line in sys.stdin.buffer:
                pending.put(line)
        finally:
            eof.set()
            pending.put(None)

    def forward_stdout():
        for line in child.stdout:
            if output_closed.is_set():
                continue
            try:
                sys.stdout.buffer.write(line)
                sys.stdout.buffer.flush()
            except (BrokenPipeError, OSError):
                # The consumer is gone. Continue draining the owned child's pipe.
                output_closed.set()

    input_reader = Thread(target=read_stdin, daemon=True)
    output_reader = Thread(target=forward_stdout, daemon=True)
    input_reader.start()
    output_reader.start()
    delayed = False
    try:
        while True:
            line = pending.get()
            if line is None or eof.is_set():
                break
            request = json.loads(line)
            params = request.get('params', {})
            value = params.get('arguments', {}) if isinstance(params, dict) else {}
            if not delayed and request.get('method') == 'tools/call' and isinstance(params, dict) and params.get('name') == 'query_incident' and isinstance(value, dict) and value.get('kind') == 'baseline':
                delayed = True
                runtime['baseline_delayed'] = True
                write(runtime_path, runtime)
                marker = {
                    'scope': 'first actual baseline held before original MCP admission',
                    'tool': 'query_incident', 'kind': 'baseline', 'request_id': request.get('id'),
                    'received_at': datetime.now(UTC).isoformat(), 'delay_seconds': DELAY_SECONDS,
                    'forwarded_to_original_driver': False, 'forwarded_at': None,
                    'cancelled_during_delay': False, 'cancelled_at': None,
                }
                write(marker_path, marker)
                if eof.wait(DELAY_SECONDS):
                    marker['cancelled_during_delay'] = True
                    marker['cancelled_at'] = datetime.now(UTC).isoformat()
                    write(marker_path, marker)
                    break
                child.stdin.write(line)
                child.stdin.flush()
                marker['forwarded_to_original_driver'] = True
                marker['forwarded_at'] = datetime.now(UTC).isoformat()
                write(marker_path, marker)
                continue
            child.stdin.write(line)
            child.stdin.flush()
    finally:
        runtime['stdin_eof_observed'] = eof.is_set()
        runtime['stdin_eof_observed_at'] = datetime.now(UTC).isoformat() if eof.is_set() else None
        child.stdin.close()
        # Let unmodified model.py observe EOF and run its own bounded server cleanup.
        try:
            child.wait(timeout=12)
        except subprocess.TimeoutExpired:
            runtime['cleanup_escalated'] = True
            child.terminate()
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=5)
        output_reader.join(timeout=1)
        runtime['owned_original_driver_exit_code'] = child.returncode
        runtime['finished_at'] = datetime.now(UTC).isoformat()
        write(runtime_path, runtime)


if __name__ == '__main__':
    main()
