"""Derive normal-arm evidence from a closed failed run without changing its status."""

from collections import Counter
from datetime import UTC, datetime
import gzip
import hashlib
import io
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import statistics
import sys
import tarfile

ROOT = Path('/Users/xiangfu/.codex/worktrees/6789/mcp-pinot-incidents')
OUTPUTS = ROOT / 'examples/incident_replay/output'
TRIAL = 'host-receipts-v1'
SOURCE = OUTPUTS / TRIAL
DESTINATION = ROOT / 'examples/incident_replay/evidence/2026-10-08-host-receipts'
PROBE = OUTPUTS / 'owned-telemetry-probe-v1'
BACKUP = Path('/tmp/incident-host-receipts-v1-backup')
CORRECTED = OUTPUTS / 'host-timeout-cleanup-v2'
INSTALLED_CLI_OBSERVATION = Path('/tmp/incident-installed-cli-observation.json')
FAILURE_PRESERVATION = Path('/tmp/incident-host-timeout-failure-evidence-v1')
SOURCE_COMMIT = '85ac85eefc65e3ef4538319224a9e15e65c0a82f'
ORIGINAL_EXPORTER = Path('/tmp/incident_host_receipts_bundle.py')
ORIGINAL_EXPORTER_SHA = 'd53e4cecc842056c1acc92c14b55648939c03a3921d03a94b33eea4b6f3a7155'
ORIGINAL_DRIVER_SHA = {
    'incident_host_receipts_live.py': '01850f92eb07af743d457e99da6cb335f0ac975a06efdc4396a07797b9889874',
    'incident_delayed_query_proxy.py': 'cfb7c84242f16500c0ce507373e212f7383db9a94d203c47764decfff88b8341',
}
EXPECTED_FAILURE = {
    'error_type': 'RuntimeError',
    'detail': 'Intentional host-timeout probe failed; retained original artifacts, no rerun.',
}
FAILED_PROBE_CHECKS = {
    'exactly_one_config_interception', 'actual_baseline_held_without_forwarding',
    'baseline_not_admitted_as_native_sql', 'actual_host_deadline_observed',
    'original_finish_not_verified', 'no_fabricated_finish',
    'completed_cli_usage_remains_unknown', 'no_completed_provider_receipt',
    'owned_partial_snapshot_observed', 'partial_snapshot_not_complete_usage',
    'no_completed_turn_claim', 'owned_session_archived_and_preserved',
    'owned_proxy_group_inherited', 'owned_delayed_children_stopped',
}
CORRECTED_CHECKS = {
    'exactly_one_config_interception', 'actual_host_deadline_observed',
    'original_finish_not_verified', 'no_fabricated_finish',
    'completed_cli_usage_remains_unknown', 'no_completed_provider_receipt',
    'owned_partial_snapshot_observed', 'partial_snapshot_not_complete_usage',
    'no_completed_turn_claim', 'owned_session_archived_and_preserved',
    'no_late_baseline_forwarding', 'baseline_not_admitted_as_native_sql',
    'original_prediction_calls_equal_final_closed_audit', 'stdin_eof_observed',
    'original_model_proxy_cleanup_not_escalated', 'owned_delayed_children_stopped',
    'owned_mcp_group_empty', 'owned_cli_process_stopped',
    'native_group_separate_from_cli_and_mcp', 'source_unchanged',
}
FIELDS = ('kind', 'service', 'version', 'zone')
TOKEN_FIELDS = ('input_tokens', 'cached_input_tokens', 'cache_write_input_tokens', 'output_tokens', 'reasoning_output_tokens')
EXPECTED_INITIAL = ['begin_investigation', 'baseline', 'incident', 'watermark', 'changes', 'get_trace']
SNAPSHOTS = {}
FILES = {}
LINEAGE = {}


def snapshot(path):
    if path not in SNAPSHOTS:
        if path.is_symlink() or not path.is_file():
            raise ValueError(f'Only original regular files may be exported: {path}')
        SNAPSHOTS[path] = path.read_bytes()
    return SNAPSHOTS[path]


def document(path):
    return json.loads(snapshot(path))


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return digest(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode())


def outcome(case):
    hypothesis = case.get('hypothesis')
    return case.get('status'), ({field: hypothesis.get(field) for field in FIELDS} if hypothesis else None)


def finite(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def stats(values):
    if not values:
        return {'count': 0, 'sum': 'UNKNOWN', 'median': 'UNKNOWN', 'mean': 'UNKNOWN', 'min': 'UNKNOWN', 'max': 'UNKNOWN'}
    if not all(finite(value) for value in values):
        raise ValueError('Timing samples require finite nonnegative values.')
    return {'count': len(values), 'sum': sum(values), 'median': statistics.median(values), 'mean': statistics.mean(values), 'min': min(values), 'max': max(values)}


def signed_stats(values):
    if not values:
        return {'count': 0, 'sum': 'UNKNOWN', 'median': 'UNKNOWN', 'mean': 'UNKNOWN', 'min': 'UNKNOWN', 'max': 'UNKNOWN'}
    if not all(type(value) in (int, float) and math.isfinite(value) for value in values):
        raise ValueError('Pair deltas require finite values.')
    return {'count': len(values), 'sum': sum(values), 'median': statistics.median(values), 'mean': statistics.mean(values), 'min': min(values), 'max': max(values)}


def cases(document_value):
    result = {case['case_id']: case for case in document_value['cases']}
    if document_value.get('schema_version') != 1 or len(result) != len(document_value['cases']):
        raise ValueError('Invalid or duplicate original cases.')
    return result


def privacy_check(value):
    sensitive = {'api_key', 'password', 'access_token', 'refresh_token', 'client_secret', 'authorization', 'auth_token', 'bearer_token', 'private_key'}
    if isinstance(value, dict):
        if value.get('type') in {'reasoning', 'agent_message'}:
            raise ValueError('Private model event cannot be exported.')
        for key, item in value.items():
            if key.lower() in sensitive and item:
                raise ValueError('Credential field cannot be exported.')
            privacy_check(item)
    elif isinstance(value, list):
        for item in value:
            privacy_check(item)
    elif isinstance(value, str):
        if re.search(r'(?i)\bBearer\s+[A-Za-z0-9._~+/=-]{12,}|\bsk-[A-Za-z0-9_-]{24,}|-----BEGIN [A-Z ]*PRIVATE KEY-----', value):
            raise ValueError('Credential-shaped string cannot be exported.')


def add_original(path, prefix=TRIAL, source=SOURCE):
    data = snapshot(path)
    value = json.loads(data) if path.suffix == '.json' else [json.loads(line) for line in data.decode().splitlines()]
    privacy_check(value)
    FILES[prefix + '/' + str(path.relative_to(source))] = data
    return value


def verify_score(report, predictions, truth, predictions_path, truth_path):
    if report.get('mode') != 'model' or predictions.get('mode') != 'model':
        raise ValueError('Both comparison arms must keep mode=model scorer guards.')
    if report.get('file_sha256') != {'predictions': digest(snapshot(predictions_path)), 'truth': digest(snapshot(truth_path))}:
        raise ValueError('Score file hashes do not bind its original inputs.')
    if report.get('input_sha256') != {'predictions': canonical(predictions), 'truth': canonical(truth)}:
        raise ValueError('Score canonical hashes do not bind its archived inputs.')
    if report.get('sha256') != canonical({key: value for key, value in report.items() if key != 'sha256'}):
        raise ValueError('Original score digest is invalid.')
    from examples.incident_replay.score import score
    recomputed = score(predictions, truth)
    if {key: value for key, value in report.items() if key not in ('sha256', 'file_sha256')} != {key: value for key, value in recomputed.items() if key != 'sha256'}:
        raise ValueError('Independent scorer does not reproduce the original score.')


def filter_events(path, prefix=TRIAL, source=SOURCE):
    retained, selected_bytes, witnesses = [], [], []
    for number, raw in enumerate(snapshot(path).splitlines(keepends=True), 1):
        event = json.loads(raw)
        kind = event.get('type')
        item_kind = event.get('item', {}).get('type')
        if kind in ('thread.started', 'turn.completed', 'error', 'turn.failed') or (kind == 'item.completed' and item_kind in ('mcp_tool_call', 'error')) or (kind == 'item.started' and item_kind == 'error') or (kind == 'item.failed' and item_kind in ('mcp_tool_call', 'error')):
            privacy_check(event)
            retained.append(raw.decode())
            selected_bytes.append(raw)
            witnesses.append({'line': number, 'type': kind, 'item_type': item_kind, 'sha256': digest(raw)})
    relative = path.relative_to(source)
    member = prefix + '/cli-receipts/' + str(relative.with_name('receipts.jsonl'))
    FILES[member] = b''.join(selected_bytes)
    LINEAGE[member] = {
        'source_relative': prefix + '/' + str(relative),
        'source_sha256': digest(snapshot(path)),
        'export_sha256': digest(FILES[member]),
        'retained_records': len(retained),
        'allowed_record_lineage': witnesses,
        'filter': 'byte-identical original lines: thread.started; completed MCP/error items; started error items; safely structured failed MCP/error items; turn.completed/error/turn.failed. No reasoning, messages, request content or raw rollout records.',
    }
    return retained



def verify_cli_receipts(recorded, actual_calls, event_path, prefix=TRIAL, source=SOURCE):
    from examples.incident_replay.runner import cli_receipts
    raw_lines = snapshot(event_path).decode().splitlines() if event_path.is_file() else []
    retained = filter_events(event_path, prefix=prefix, source=source) if event_path.is_file() else []
    actual = cli_receipts(retained, actual_calls)
    original = cli_receipts(raw_lines, actual_calls)
    cached = {field: recorded.get(field, fallback) for field, fallback in (
        ('model_usage', 'UNKNOWN'), ('observed_model', 'UNKNOWN'),
        ('cli_issues', []), ('cli_warnings', []),
    )}
    if original != actual:
        raise ValueError('Publication filter dropped a CLI validation witness; refusing export.')
    if actual != cached:
        raise ValueError('Recorded CLI usage/model/issues/warnings differ from original retained receipts and audit tuples.')
    return actual


def event_usage(path):
    if not path.is_file():
        return []
    return [event['usage'] for line in snapshot(path).decode().splitlines() if (event := json.loads(line)).get('type') == 'turn.completed' and isinstance(event.get('usage'), dict)]


def genuine_usage(case, event_path):
    receipt = case.get('provider_receipt')
    if not isinstance(receipt, dict) or receipt.get('source') != 'codex.exec' or not isinstance(receipt.get('usage'), dict):
        return None
    usage = receipt['usage']
    if any(type(usage.get(field)) is not int or usage[field] < 0 for field in ('input_tokens', 'output_tokens')):
        raise ValueError('Recorded provider usage is malformed.')
    actual = event_usage(event_path)
    if len(actual) != 1 or actual[0] != usage:
        raise ValueError('Provider receipt does not bind an actual completed CLI usage event.')
    return usage


_UUID = re.compile(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}')
_HOST_KEYS = {'source', 'thread_id', 'turn_id', 'cwd_binding_verified', 'host_selected_model', 'host_selected_effort', 'host_selected_provider', 'provider_attested_model', 'billing', 'token_usage', 'completion', 'lineage'}
_HOST_RECORD_FIELDS = {
    'session_meta': {'id', 'cwd', 'model_provider'},
    'task_started': {'turn_id'},
    'turn_context': {'turn_id', 'model', 'effort'},
    'token_count': {'total_token_usage', 'last_token_usage'},
    'task_complete': {'turn_id'},
}
_DIAGNOSTIC_TIMINGS = ('host_telemetry_capture_ms', 'host_session_archive_ms', 'telemetry_elapsed_ms', 'full_elapsed_ms')


def token_snapshot(value):
    if not isinstance(value, dict) or set(value) != set(TOKEN_FIELDS) | {'total_tokens'}:
        raise ValueError('Owned snapshot is missing or has unallowlisted token fields.')
    if any(type(number) is not int or number < 0 for number in value.values()):
        raise ValueError('Owned snapshots require nonnegative integer counters.')
    if value['total_tokens'] != value['input_tokens'] + value['output_tokens'] or value['cached_input_tokens'] > value['input_tokens'] or value['cache_write_input_tokens'] > value['input_tokens'] or value['reasoning_output_tokens'] > value['output_tokens']:
        raise ValueError('Owned snapshot token subsets are inconsistent.')
    return value


def event_thread(path):
    identifiers = [event.get('thread_id') for raw in snapshot(path).splitlines() if (event := json.loads(raw)).get('type') == 'thread.started']
    if len(identifiers) != 1 or not isinstance(identifiers[0], str) or not _UUID.fullmatch(identifiers[0]):
        raise ValueError('Require one actual CLI thread.started owned UUID.')
    return identifiers[0]


def selected_text(payload, key):
    value = payload.get(key)
    if value is None:
        return 'UNKNOWN'
    if not isinstance(value, str) or not value.strip():
        raise ValueError('Host selection requires nonempty string metadata.')
    return value


def verify_host_metadata(case, directory, prefix=TRIAL, source=SOURCE, owned_directory=None):
    telemetry = case.get('host_telemetry')
    if not isinstance(telemetry, dict):
        if (directory / 'host-telemetry.json').is_file():
            raise ValueError('Stored host metadata is absent from its actual prediction.')
        return {'present': False, 'error': case.get('host_telemetry_error', 'UNKNOWN'), 'host_selected_model': 'UNKNOWN', 'host_selected_effort': 'UNKNOWN', 'host_selected_provider': 'UNKNOWN', 'provider_attested_model': 'UNKNOWN', 'billing': 'UNKNOWN'}
    stored_path = directory / 'host-telemetry.json'
    if stored_path.is_file():
        original = add_original(stored_path, prefix=prefix, source=source)
        if original != telemetry:
            raise ValueError('Stored host diagnostics differ from their actual prediction.')
    elif not case.get('host_telemetry_error'):
        raise ValueError('Owned diagnostics lack their original stored file or write-failure receipt.')
    if set(telemetry) != _HOST_KEYS:
        raise ValueError('Owned diagnostics contain unallowlisted fields.')
    if telemetry['thread_id'] != event_thread(directory / 'events.jsonl') or not _UUID.fullmatch(telemetry['turn_id']) or telemetry['cwd_binding_verified'] is not True:
        raise ValueError('Host diagnostics do not bind the actual owned CLI thread.')
    if telemetry['provider_attested_model'] != 'UNKNOWN' or telemetry['billing'] != 'UNKNOWN':
        raise ValueError('Host metadata cannot mint provider identity or billing.')
    if set(telemetry['token_usage']) != {'complete', 'latest_total', 'latest_response', 'snapshot_count', 'cli_completed_usage_matches'} or telemetry['token_usage']['complete'] is not False:
        raise ValueError('Host snapshots must remain partial diagnostic usage.')
    if set(telemetry['completion']) != {'task_complete_observed', 'cli_completed_turn_observed'}:
        raise ValueError('Unallowlisted host completion metadata.')
    if any(type(value) is not bool for value in telemetry['completion'].values()):
        raise ValueError('Host completion observations must be booleans.')
    lineage = telemetry['lineage']
    if not {'source_path', 'source_sha256', 'allowed_records'}.issubset(lineage) or set(lineage) - {'source_path', 'source_sha256', 'allowed_records', 'archived_source_path'} or not re.fullmatch(r'[0-9a-f]{64}', lineage['source_sha256']):
        raise ValueError('Invalid owned metadata lineage; raw rollouts are never opened here.')
    records = lineage['allowed_records']
    if not isinstance(records, list) or not records:
        raise ValueError('Owned metadata must retain its allowlisted record lineage.')
    counts = Counter()
    timestamps = []
    previous_total = None
    window = case.get('host_telemetry_window', {})
    started = datetime.fromisoformat(window['started_at'])
    finished = datetime.fromisoformat(window['finished_at'])
    for record in records:
        if set(record) != {'line', 'type', 'sha256', 'timestamp', 'payload'} or record['type'] not in _HOST_RECORD_FIELDS or not re.fullmatch(r'[0-9a-f]{64}', record['sha256']) or type(record['line']) is not int or record['line'] < 1:
            raise ValueError('Unallowlisted owned record lineage.')
        kind, payload = record['type'], record['payload']
        if not isinstance(payload, dict) or set(payload) - _HOST_RECORD_FIELDS[kind]:
            raise ValueError('Unallowlisted owned record payload.')
        timestamp = datetime.fromisoformat(record['timestamp'].replace('Z', '+00:00'))
        if started.tzinfo is None or finished.tzinfo is None or timestamp.tzinfo is None or not started <= timestamp <= finished:
            raise ValueError('Host record is outside the actual CLI capture window.')
        timestamps.append(timestamp)
        counts[kind] += 1
        if kind == 'session_meta' and (payload.get('id') != telemetry['thread_id'] or Path(payload.get('cwd', '')).resolve() != ((owned_directory or directory) / 'workspace').resolve()):
            raise ValueError('Owned session/cwd differs from the actual case workspace.')
        if kind in ('turn_context', 'task_started', 'task_complete') and payload.get('turn_id') != telemetry['turn_id']:
            raise ValueError('Owned record has a foreign turn ID.')
        if kind == 'token_count':
            total = token_snapshot(payload.get('total_token_usage'))
            last = token_snapshot(payload.get('last_token_usage'))
            if any(last[key] > total[key] for key in total) or (previous_total is not None and any(total[key] < previous_total[key] for key in total)):
                raise ValueError('Owned snapshots have decreasing totals or response counts above totals.')
            previous_total = total
    expected = ['session_meta', 'task_started', 'turn_context', *(['token_count'] * counts['token_count']), *(['task_complete'] if counts['task_complete'] else [])]
    if [record['type'] for record in records] != expected or any(a > b for a, b in zip(timestamps, timestamps[1:])):
        raise ValueError('Owned host metadata sequence differs from one fresh turn.')
    session = next(record['payload'] for record in records if record['type'] == 'session_meta')
    context = next(record['payload'] for record in records if record['type'] == 'turn_context')
    selected = {'host_selected_model': selected_text(context, 'model'), 'host_selected_effort': selected_text(context, 'effort'), 'host_selected_provider': selected_text(session, 'model_provider')}
    if any(telemetry[key] != value for key, value in selected.items()):
        raise ValueError('Host selection differs from its retained owned metadata records.')
    usage = telemetry['token_usage']
    if type(usage['snapshot_count']) is not int or usage['snapshot_count'] != counts['token_count']:
        raise ValueError('Owned snapshot count differs from its record lineage.')
    if counts['token_count']:
        latest_record = next(record for record in reversed(records) if record['type'] == 'token_count')
        if usage['latest_total'] != latest_record['payload']['total_token_usage'] or usage['latest_response'] != latest_record['payload']['last_token_usage']:
            raise ValueError('Owned latest counts differ from their retained snapshot.')
    elif usage['latest_total'] != 'UNKNOWN' or usage['latest_response'] != 'UNKNOWN':
        raise ValueError('Missing snapshots must remain UNKNOWN.')
    completed = event_usage(directory / 'events.jsonl')
    if telemetry['completion']['task_complete_observed'] != bool(counts['task_complete']) or telemetry['completion']['cli_completed_turn_observed'] != bool(completed) or usage['cli_completed_usage_matches'] != bool(completed):
        raise ValueError('Owned completion metadata differs from actual CLI completion.')
    if completed and (len(completed) != 1 or any(usage['latest_total'].get(key) != value for key, value in completed[0].items())):
        raise ValueError('Owned snapshots do not reconcile to actual CLI usage.')
    if case.get('host_session_archived') is True and (case.get('host_session_bytes_preserved') is not True or 'archived_source_path' not in lineage):
        raise ValueError('Archive success lacks a recorded byte-preservation witness.')
    # Paths and hashes identify the owned source; this exporter never reads them.
    return {'present': True, 'host_selected_model': telemetry['host_selected_model'], 'host_selected_effort': telemetry['host_selected_effort'], 'host_selected_provider': telemetry['host_selected_provider'], 'provider_attested_model': 'UNKNOWN', 'billing': 'UNKNOWN', 'snapshot_count': usage['snapshot_count'], 'snapshot_complete': False, 'cli_completed_usage_matches': usage['cli_completed_usage_matches'], 'archived': case.get('host_session_archived', False), 'archived_bytes_preserved': case.get('host_session_bytes_preserved', False), 'error': case.get('host_telemetry_error')}


def require_stopped(pid):
    if type(pid) is not int or pid <= 0:
        raise ValueError('An owned positive PID is required.')
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return
    raise ValueError('An owned recorded process still exists; refusing export.')


def validate_closed_normal_runtime(runtime, failed_report, driver):
    """Permit only the exact closed v1 failure, never any other failed/active run."""
    if (
        runtime.get('evaluation_complete') is not False
        or runtime.get('evaluation_valid') is not False
        or runtime.get('failure') != EXPECTED_FAILURE
        or runtime.get('source_unchanged') is not True
        or not runtime.get('stopped_at')
        or runtime.get('source_drift')
        or not runtime.get('source_sha256')
        or runtime.get('source_sha256') != runtime.get('source_sha256_end')
        or runtime.get('git') != {'head': SOURCE_COMMIT, 'dirty': False}
    ):
        raise ValueError('Normal derivation requires the exact closed failed v1 runtime.')
    if type(runtime.get('native_exit_code')) is not int:
        raise ValueError('The closed failed runtime lacks its owned native exit receipt.')
    checks = failed_report.get('checks')
    if (
        failed_report.get('probe_complete') is not True
        or failed_report.get('all_passed') is not False
        or not isinstance(checks, dict)
        or set(checks) != FAILED_PROBE_CHECKS
        or checks['owned_delayed_children_stopped'] is not False
        or any(value is not True for key, value in checks.items() if key != 'owned_delayed_children_stopped')
        or failed_report.get('source_unchanged') is not True
        or failed_report.get('source_sha256') != runtime['source_sha256']
        or failed_report.get('source_sha256_end') != runtime['source_sha256']
        or failed_report.get('git') != runtime['git']
    ):
        raise ValueError('Only the single documented delayed-child cleanup failure is derivable.')
    if (
        driver.get('git_before') != runtime['git']
        or driver.get('source_unchanged') is not True
        or driver.get('source_sha256_before') != runtime['source_sha256']
        or driver.get('source_sha256_end') != runtime['source_sha256']
        or type(driver.get('timeout_probe_invocations')) is not int
        or driver.get('timeout_probe_invocations') != 1
        or driver.get('run_settings') != {
            'start_seed': 450, 'seeds': 3, 'extended_cases': True, 'mode': 'model',
            'compare_collection': True, 'host_telemetry': True, 'cli_defaults': True,
            'model_deadline_seconds': 60,
        }
    ):
        raise ValueError('Original wrapper source/settings do not bind the closed normal arms.')


def validate_timeout_prediction(report, prediction):
    if (
        report.get('prediction') != prediction
        or report.get('excluded_from_model_accuracy') is not True
        or report.get('excluded_from_collection_comparison') is not True
        or report.get('host_deadline_seconds') != 30
        or report.get('injected_baseline_delay_seconds') != 60
        or prediction.get('timed_out') is not True
        or prediction.get('verified_finish') is not False
        or prediction.get('model_usage') != 'UNKNOWN'
        or prediction.get('raw_finish') is not None
        or 'provider_receipt' in prediction
    ):
        raise ValueError('Intentional timeout cannot be rewritten into normal finish/usage.')


def validate_late_failure_audit(failure_calls, closed_calls, failure_marker, closed_marker, deadline):
    if len(closed_calls) != len(failure_calls) + 1 or closed_calls[:len(failure_calls)] != failure_calls:
        raise ValueError('Closed failed audit must preserve its original prefix and one late call.')
    late = closed_calls[-1]
    wire = late.get('response', {})
    if (
        late.get('tool') != 'query_incident'
        or late.get('args', {}).get('kind') != 'baseline'
        or not finite(late.get('started_ms'))
        or not finite(late.get('completed_ms'))
        or late['started_ms'] <= deadline * 1000
        or late['completed_ms'] < late['started_ms']
        or not (wire.get('error') or wire.get('result', {}).get('isError'))
        or failure_marker.get('forwarded_to_original_driver') is not False
        or failure_marker.get('forwarded_at') is not None
        or closed_marker.get('forwarded_to_original_driver') is not True
        or {key: value for key, value in closed_marker.items() if key not in ('forwarded_to_original_driver', 'forwarded_at')}
        != {key: value for key, value in failure_marker.items() if key not in ('forwarded_to_original_driver', 'forwarded_at')}
        or not closed_marker.get('forwarded_at')
        or datetime.fromisoformat(closed_marker['forwarded_at']) <= datetime.fromisoformat(closed_marker['received_at'])
    ):
        raise ValueError('The retained late-forwarding failure does not match the actual closed audit.')


def seal_failed_timeout_probe(runtime):
    prefix = 'failed-host-timeout-v1/failure-time'
    for filename in ('runtime.json', 'temporary-driver.json'):
        add_original(BACKUP / filename, prefix=prefix, source=BACKUP)
    report = add_original(BACKUP / 'host-timeout-probe.json', prefix=prefix, source=BACKUP)
    prediction = add_original(BACKUP / 'host-timeout-probe/prediction.json', prefix=prefix, source=BACKUP)
    validate_timeout_prediction(report, prediction)
    directory = BACKUP / 'host-timeout-probe/0'
    original_directory = SOURCE / 'host-timeout-probe/0'
    audit = add_original(directory / 'calls.jsonl', prefix=prefix, source=BACKUP)
    if audit != prediction.get('calls'):
        raise ValueError('Failure-time prediction must match its retained failure-time audit.')
    cli = verify_cli_receipts(prediction, audit, directory / 'events.jsonl', prefix=prefix, source=BACKUP)
    metadata = verify_host_metadata(prediction, directory, prefix=prefix, source=BACKUP, owned_directory=original_directory)
    failure_marker = add_original(directory / 'delayed-baseline-request.json', prefix=prefix, source=BACKUP)
    add_original(directory / 'delayed-proxy-runtime.json', prefix=prefix, source=BACKUP)
    prefix = 'failed-host-timeout-v1/closed'
    for filename in ('runtime.json', 'temporary-driver.json', 'host-timeout-probe.json', 'host-timeout-probe/prediction.json'):
        add_original(SOURCE / filename, prefix=prefix, source=SOURCE)
        if snapshot(BACKUP / filename) != snapshot(SOURCE / filename):
            raise ValueError('An original combined failure report or prediction was rewritten.')
    closed_calls = add_original(original_directory / 'calls.jsonl', prefix=prefix, source=SOURCE)
    closed_marker = add_original(original_directory / 'delayed-baseline-request.json', prefix=prefix, source=SOURCE)
    closed_proxy = add_original(original_directory / 'delayed-proxy-runtime.json', prefix=prefix, source=SOURCE)
    add_original(original_directory / 'host-telemetry.json', prefix=prefix, source=SOURCE)
    filter_events(original_directory / 'events.jsonl', prefix=prefix, source=SOURCE)
    if snapshot(directory / 'events.jsonl') != snapshot(original_directory / 'events.jsonl') or snapshot(directory / 'host-telemetry.json') != snapshot(original_directory / 'host-telemetry.json'):
        raise ValueError('Failure-time CLI or allowlisted host metadata changed after closure.')
    validate_late_failure_audit(audit, closed_calls, failure_marker, closed_marker, report['host_deadline_seconds'])
    if not closed_proxy.get('finished_at') or type(closed_proxy.get('owned_original_driver_exit_code')) is not int:
        raise ValueError('Late closed proxy lacks a final owned-child exit receipt.')
    for key in ('proxy_pid', 'model_proxy_pid'):
        require_stopped(closed_proxy.get(key))
    preservation = add_original(FAILURE_PRESERVATION / 'lineage.json', prefix='failed-host-timeout-v1/preservation', source=FAILURE_PRESERVATION)
    if preservation.get('original_combined_flags') != {'evaluation_complete': False, 'evaluation_valid': False} or len(preservation.get('files', {})) != 12:
        raise ValueError('The preserved failure witnesses must retain the original invalid combined status.')
    for name, witness in preservation['files'].items():
        relative = PurePosixPath(name)
        if relative.is_absolute() or '..' in relative.parts or relative.parts[0] not in ('failure-time', 'final-closed'):
            raise ValueError('Unsafe original failure witness path.')
        expected_source = (BACKUP if relative.parts[0] == 'failure-time' else SOURCE).joinpath(*relative.parts[1:])
        if witness.get('source_path') != str(expected_source) or witness.get('sha256') != digest(snapshot(expected_source)) or witness.get('bytes') != len(snapshot(expected_source)):
            raise ValueError('Preservation lineage does not match the unchanged original failure file.')
        copied = FAILURE_PRESERVATION / name
        if snapshot(copied) != snapshot(expected_source):
            raise ValueError('A preserved failure witness differs from its exact original file.')
        add_original(copied, prefix='failed-host-timeout-v1/preservation', source=FAILURE_PRESERVATION)
    return {
        'scope': 'Original separate timeout fault failed cleanup. Both failure-time snapshots and final late-forwarded audit are retained; never used in any normal-arm quality/latency/token total.',
        'original_combined_evaluation_complete': runtime['evaluation_complete'],
        'original_combined_evaluation_valid': runtime['evaluation_valid'],
        'all_passed': False,
        'checks': report['checks'],
        'failure_time_actual_calls': len(audit),
        'closed_actual_calls': len(closed_calls),
        'late_baseline_forwarded_after_deadline': True,
        'late_baseline_failed_response': True,
        'failure_time_audit_sha256': digest(snapshot(directory / 'calls.jsonl')),
        'closed_audit_sha256': digest(snapshot(original_directory / 'calls.jsonl')),
        'failure_time_marker_sha256': digest(snapshot(directory / 'delayed-baseline-request.json')),
        'closed_marker_sha256': digest(snapshot(original_directory / 'delayed-baseline-request.json')),
        'verified_finish': False,
        'model_usage': 'UNKNOWN',
        'completed_provider_receipt_present': False,
        'host_metadata': metadata,
        'cli_issues': cli['cli_issues'],
        'owned_late_children_currently_stopped': True,
        'historical_cleanup_check_remains_failed': True,
        'preservation_lineage_sha256': digest(snapshot(FAILURE_PRESERVATION / 'lineage.json')),
    }


def seal_corrected_timeout_probe(expected_source):
    prefix = 'corrected-host-timeout-v2'
    runtime = add_original(CORRECTED / 'runtime.json', prefix=prefix, source=CORRECTED)
    if (
        runtime.get('evaluation_complete') is not True
        or runtime.get('evaluation_valid') is not True
        or runtime.get('source_unchanged') is not True
        or not runtime.get('stopped_at')
        or runtime.get('failure')
        or runtime.get('source_drift')
        or runtime.get('source_sha256') != expected_source
        or runtime.get('source_sha256_end') != expected_source
        or runtime.get('git') != {'head': SOURCE_COMMIT, 'dirty': False}
        or type(runtime.get('native_exit_code')) is not int
        or runtime.get('owned_process_stopped') is not True
        or runtime.get('temporary_drivers_unchanged') is not True
        or runtime.get('timeout_audit_stable_after_native_cleanup') is not True
        or runtime.get('timeout_marker_stable_after_native_cleanup') is not True
    ):
        raise ValueError('Corrected v2 probe is missing, active, failed, or changed-source.')
    require_stopped(runtime.get('owned_pid'))
    report = add_original(CORRECTED / 'host-timeout-probe.json', prefix=prefix, source=CORRECTED)
    prediction = add_original(CORRECTED / 'model/0/prediction.json', prefix=prefix, source=CORRECTED)
    validate_timeout_prediction(report, prediction)
    if report.get('probe_complete') is not True or report.get('all_passed') is not True or not isinstance(report.get('checks'), dict) or set(report['checks']) != CORRECTED_CHECKS or any(value is not True for value in report['checks'].values()) or report.get('source_sha256') != expected_source or report.get('source_sha256_end') != expected_source or report.get('source_unchanged') is not True:
        raise ValueError('Corrected timeout proof must independently pass every original check.')
    directory = CORRECTED / 'model/0'
    audit = add_original(directory / 'calls.jsonl', prefix=prefix, source=CORRECTED)
    if audit != prediction.get('calls') or any(call.get('tool') == 'query_incident' and call.get('args', {}).get('kind') == 'baseline' for call in audit):
        raise ValueError('Corrected timeout audit contains an admitted baseline or altered prediction.')
    cli = verify_cli_receipts(prediction, audit, directory / 'events.jsonl', prefix=prefix, source=CORRECTED)
    metadata = verify_host_metadata(prediction, directory, prefix=prefix, source=CORRECTED)
    latest = prediction.get('host_telemetry', {}).get('token_usage', {}).get('latest_total')
    if not metadata.get('present') or prediction.get('host_telemetry_error') or not metadata.get('archived') or not metadata.get('archived_bytes_preserved') or not isinstance(latest, dict) or latest.get('input_tokens', 0) <= 0 or latest.get('output_tokens', 0) <= 0 or genuine_usage(prediction, directory / 'events.jsonl') is not None:
        raise ValueError('Corrected timeout requires actual owned partial diagnostics and no provider receipt.')
    marker = add_original(directory / 'delayed-baseline-request.json', prefix=prefix, source=CORRECTED)
    proxy = add_original(directory / 'delayed-proxy-runtime.json', prefix=prefix, source=CORRECTED)
    if marker.get('forwarded_to_original_driver') is not False or marker.get('forwarded_at') is not None or marker.get('cancelled_during_delay') is not True or not marker.get('cancelled_at') or proxy.get('stdin_eof_observed') is not True or proxy.get('cleanup_escalated') is not False or not proxy.get('finished_at') or type(proxy.get('owned_original_driver_exit_code')) is not int:
        raise ValueError('Corrected timeout forwarded the held baseline after cancellation.')
    if report.get('audit_sha256_after_cleanup') != digest(snapshot(directory / 'calls.jsonl')) or report.get('marker_sha256_after_cleanup') != digest(snapshot(directory / 'delayed-baseline-request.json')):
        raise ValueError('Corrected fault artifacts changed after their recorded cleanup.')
    for key in ('proxy_pid', 'model_proxy_pid'):
        require_stopped(proxy.get(key))
    parity = add_original(CORRECTED / 'parity.json', prefix=prefix, source=CORRECTED)
    if parity.get('full_row_parity') is not True or parity.get('source_rows') != parity.get('native_rows') or parity.get('source_sha256') != parity.get('native_sha256'):
        raise ValueError('Corrected isolated probe lacks actual full-row native parity.')
    driver = add_original(CORRECTED / 'temporary-driver.json', prefix=prefix, source=CORRECTED)
    if driver.get('temporary_drivers') != runtime.get('temporary_drivers') or driver.get('temporary_drivers') != runtime.get('temporary_drivers_end') or driver.get('temporary_drivers') != report.get('temporary_drivers') or {Path(name).resolve() for name in driver.get('temporary_drivers', {})} != {Path('/tmp/incident_host_timeout_probe_v2.py').resolve(), Path('/tmp/incident_delayed_query_proxy_v2.py').resolve()}:
        raise ValueError('Corrected fault driver receipts differ from their frozen actual sources.')
    cli_process = driver.get('cli_process', {})
    if driver.get('actual_interception_count') != 1 or len(driver.get('cli_invocation_changes', [])) != 1 or cli_process.get('timed_out') is not True or type(cli_process.get('exit_code')) is not int or driver.get('mcp_group_is_separate_from_cli') is not True or driver.get('owned_mcp_group_state', {}).get('empty') is not True or driver.get('owned_mcp_group_state', {}).get('remaining_processes') != '':
        raise ValueError('Corrected timeout lacks its real CLI/configuration/group cleanup receipt.')
    change = driver['cli_invocation_changes'][0]
    if change.get('all_other_cli_arguments_identical') is not True or change.get('remaining_proxy_arguments_identical') is not True:
        raise ValueError('Corrected fault changed arguments outside the one proxy interception.')
    require_stopped(cli_process.get('pid'))
    for name, expected_hash in driver.get('temporary_drivers', {}).items():
        path = Path(name)
        if path.resolve().parent != Path('/tmp').resolve() or path.resolve() in {Path('/tmp/incident_host_receipts_live.py').resolve(), Path('/tmp/incident_delayed_query_proxy.py').resolve()}:
            raise ValueError('Corrected drivers must be new owned temporary files.')
        raw = snapshot(path)
        if digest(raw) != expected_hash:
            raise ValueError('Corrected timeout driver changed after the actual probe.')
        privacy_check(raw.decode())
        FILES['temporary-drivers/corrected/' + path.name] = raw
    if len(driver.get('temporary_drivers', {})) != 2:
        raise ValueError('Corrected timeout probe requires its two exact new driver sources.')
    return {
        'scope': 'One separately corrected timeout-cleanup fault probe; excluded from all original 18 paired outcomes, latency samples and token totals.',
        'all_passed': True, 'checks': report['checks'],
        'evaluation_complete': True, 'evaluation_valid': True,
        'verified_finish': False, 'model_usage': 'UNKNOWN',
        'completed_provider_receipt_present': False,
        'actual_calls': len(audit), 'cli_issues': cli['cli_issues'],
        'host_metadata': metadata, 'no_late_baseline_forwarding': True,
        'owned_native_and_proxy_processes_stopped': True,
        'source_commit': SOURCE_COMMIT,
    }


def normal_derivation_receipt(runtime, failed_report, drivers):
    fault_start = datetime.fromisoformat(failed_report['started_at'])
    if fault_start.tzinfo is None:
        raise ValueError('Original separate fault start must have a timezone.')
    witnesses = {}
    for path, raw in list(SNAPSHOTS.items()):
        if not path.is_relative_to(SOURCE):
            continue
        relative = path.relative_to(SOURCE)
        if relative.parts[0] in ('host-timeout-probe', 'runtime.json', 'temporary-driver.json', 'host-timeout-probe.json'):
            continue
        backup = BACKUP / relative
        if snapshot(backup) != raw:
            raise ValueError('Normal evidence differs from its retained original failure-time copy.')
        modified_ns = path.stat().st_mtime_ns
        if modified_ns / 1_000_000_000 >= fault_start.timestamp():
            raise ValueError('A normal prediction/score/input was modified after the separate fault began.')
        witnesses[str(relative)] = {'sha256': digest(raw), 'bytes': len(raw), 'mtime_ns': modified_ns, 'unchanged_from_failure_time_backup': True, 'completed_before_separate_fault': True}
    scores = ('model_default-score.json', 'model_planned-score.json')
    if any(name not in witnesses for name in scores):
        raise ValueError('Both original scored arms must precede the separate fault.')
    return {
        'schema_version': 1,
        'scope': 'Separate normal-arm derivation from all immutable 18 original pairs; this receipt does not change or replace the failed combined runtime.',
        'original_combined_evaluation_complete': False,
        'original_combined_evaluation_valid': False,
        'original_combined_failure': runtime['failure'],
        'normal_arms_revalidated': True,
        'all_original_pair_ids_and_predictions_retained': True,
        'case_count_per_arm': 18,
        'quality_and_latency_inclusion': 'All original 18 pairs; no case selection, replacement, or model rerun.',
        'source_commit': SOURCE_COMMIT,
        'source_sha256': runtime['source_sha256'],
        'scored_before_separate_fault': {
            'fault_started_at': failed_report['started_at'],
            'original_score_mtime_ns': {name: witnesses[name]['mtime_ns'] for name in scores},
            'wrapper_sha256': drivers['temporary_driver_sha256'],
            'wrapper_sequence': 'The byte-identical hashed wrapper requires both arm score files and six successful original probes before its one separate timeout_probe invocation.',
        },
        'original_normal_input_witnesses': witnesses,
        'owned_original_native_process_stopped': True,
        'failed_timeout_v1_preserved': True,
        'corrected_timeout_v2_excluded_from_normal_pairs': True,
        'provider_attested_model': 'UNKNOWN', 'billing': 'UNKNOWN',
    }


def seal_preliminary_probe():
    # Only already filtered probe metadata is read; never open/copy its raw rollout.
    for filename in ('runtime.json', 'model-runtime.json', 'parity.json', 'cli-invocation-change.json', 'owned-session-metadata.json', 'owned-session-lineage.json', 'owned-token-record-shapes.json', 'owned-token-usage-records.json', 'owned-token-record-summary.json', 'archive-cleanup.json', 'model/0/calls.json'):
        add_original(PROBE / filename, prefix='preliminary-owned-probe', source=PROBE)
    runtime = document(PROBE / 'runtime.json')
    model_runtime = document(PROBE / 'model-runtime.json')
    calls = document(PROBE / 'model/0/calls.json')['calls']
    audit = add_original(PROBE / 'model/0/calls.jsonl', prefix='preliminary-owned-probe', source=PROBE)
    if calls != audit:
        raise ValueError('Preliminary probe calls differ from their original audit.')
    cli = verify_cli_receipts(model_runtime, audit, PROBE / 'model/0/events.jsonl', prefix='preliminary-owned-probe', source=PROBE)
    metadata = document(PROBE / 'owned-session-metadata.json')
    numeric = document(PROBE / 'owned-token-usage-records.json')['records']
    if metadata.get('thread_id') != event_thread(PROBE / 'model/0/events.jsonl') or metadata.get('cwd_binding_verified') is not True:
        raise ValueError('Preliminary probe metadata does not bind its actual CLI thread.')
    for row in numeric:
        allowed = {'timestamp', 'ordinal', 'type', 'thread_id', 'turn_id', 'usage_keys', 'usage', 'thread_token_usage_keys', 'thread_token_usage', 'turn_token_usage_keys', 'turn_token_usage'}
        if set(row) != allowed or row['type'] != 'token_usage_record' or row['thread_id'] != metadata['thread_id']:
            raise ValueError('Preliminary numeric records contain unallowlisted fields or IDs.')
        for key in ('usage', 'thread_token_usage', 'turn_token_usage'):
            token_snapshot(row[key])
    if runtime.get('owned_process_stopped') is not True or runtime.get('source_drift') or runtime.get('compatibility_passed') is not True or runtime.get('session_archived') is not True or runtime.get('archived_raw_session_preserved') is not True or model_runtime.get('cli_issues'):
        raise ValueError('Preliminary ownership/receipt/cleanup validation failed.')
    return {'scope': 'One preliminary compatibility run, separate from all 18 pairs and intentional timeout probe; original UTC lookup failure/local-date recovery retained.', 'source_commit': runtime['git'], 'actual_calls': len(audit), 'cli_issues': cli['cli_issues'], 'host_selected_models': metadata['observed_models'], 'selected_effort': 'UNKNOWN', 'provider_attested_model': 'UNKNOWN', 'billing': 'UNKNOWN', 'actual_completed_usage': cli['model_usage'], 'original_lookup_error': runtime.get('error'), 'lookup_recovery': runtime.get('lookup_recovery'), 'session_archived': runtime['session_archived'], 'raw_session_byte_preservation_recorded': runtime['archived_raw_session_preserved']}


def seal_temporary_drivers():
    receipt = add_original(SOURCE / 'temporary-driver.json')
    expected = {Path('/tmp/incident_host_receipts_live.py'), Path('/tmp/incident_delayed_query_proxy.py')}
    recorded_drivers = receipt.get('temporary_drivers', {})
    resolved_drivers = {Path(name).resolve(): value for name, value in recorded_drivers.items()}
    if set(resolved_drivers) != {path.resolve() for path in expected} or len(recorded_drivers) != 2 or receipt.get('timeout_probe_invocations') != 1 or receipt.get('source_unchanged') is not True:
        raise ValueError('Temporary execution drivers lack one unchanged-source probe receipt.')
    original_probe_bytes = snapshot(SOURCE / 'probes.json')
    original_probes = json.loads(original_probe_bytes)
    original_checks = original_probes.get('checks', [])
    if original_probes.get('all_passed') is not True or len(original_checks) != 6 or any(not isinstance(check, dict) or check.get('passed') is not True for check in original_checks):
        raise ValueError('The six original protocol-fault checks did not all pass.')
    original_probe_hash_before = digest(original_probe_bytes)
    if receipt.get('original_probes', {}).get('sha256') != original_probe_hash_before or receipt.get('original_probes', {}).get('all_passed') is not True or receipt.get('original_probes', {}).get('check_count') != 6:
        raise ValueError('Original six protocol-fault probes differ from the wrapper receipt.')
    for path in sorted(expected):
        raw = snapshot(path)
        if digest(raw) != resolved_drivers[path.resolve()] or digest(raw) != ORIGINAL_DRIVER_SHA[path.name]:
            raise ValueError('Temporary driver source changed after the actual run.')
        privacy_check(raw.decode())
        FILES['temporary-drivers/' + path.name] = raw
    exporter = Path(__file__).resolve()
    FILES['temporary-drivers/' + exporter.name] = snapshot(exporter)
    if digest(snapshot(ORIGINAL_EXPORTER)) != ORIGINAL_EXPORTER_SHA:
        raise ValueError('The original failed-run exporter was rewritten.')
    FILES['temporary-drivers/' + ORIGINAL_EXPORTER.name] = snapshot(ORIGINAL_EXPORTER)
    original_probe_hash_after = digest((SOURCE / 'probes.json').read_bytes())
    if original_probe_hash_after != original_probe_hash_before:
        raise ValueError('Original six protocol-fault probe bytes changed during sealing.')
    return {'original_probes': receipt['original_probes'], 'original_probe_hashes': {'before': original_probe_hash_before, 'after': original_probe_hash_after, 'unchanged': True}, 'temporary_driver_sha256': receipt['temporary_drivers'], 'exporter_sha256': digest(snapshot(exporter)), 'source_unchanged': receipt['source_unchanged']}


def collection_observations(calls):
    initial = calls[:6]
    order = [call.get('args', {}).get('kind') if call.get('tool') == 'query_incident' else call.get('tool') for call in initial]
    timestamps = [{'tool': call.get('tool'), 'kind': call.get('args', {}).get('kind'), 'started_ms': call.get('started_ms'), 'completed_ms': call.get('completed_ms'), 'elapsed_ms': call.get('elapsed_ms')} for call in initial]
    complete_times = len(initial) == 6 and all(finite(call.get('started_ms')) and finite(call.get('completed_ms')) and call['completed_ms'] >= call['started_ms'] for call in initial)
    return {
        'actual_first_six_call_order': order,
        'matches_requested_initial_order': order == EXPECTED_INITIAL,
        'timestamps': timestamps,
        'initial_collection_wall_ms': initial[-1]['completed_ms'] - initial[0]['started_ms'] if complete_times else 'UNKNOWN',
        'response_to_next_request_gaps_ms': [following['started_ms'] - preceding['completed_ms'] for preceding, following in zip(initial, initial[1:])] if complete_times else 'UNKNOWN',
        'sequential_nonoverlap_observed': all(following['started_ms'] >= preceding['completed_ms'] for preceding, following in zip(initial, initial[1:])) if complete_times else 'UNKNOWN',
        'onset_query_count': sum(call.get('tool') == 'query_incident' and call.get('args', {}).get('kind') == 'onset' for call in calls),
        'code_mode_single_block_proven': 'UNKNOWN: CLI exports actual MCP receipts but no execution wrapper receipt',
    }


def mode_summary(name, predictions, report, expected, case_locations):
    ledger, sql_ledger, usages = [], [], []
    native_times, mcp_times, proxy_times = [], [], []
    timed_values = {field: [] for field in ('cli_elapsed_ms', 'launch_to_first_request_ms', 'last_response_to_exit_ms', 'tool_occupancy_ms')}
    mcp_error_calls = 0
    for case in predictions['cases']:
        identity = case['case_id']
        directory = case_locations[(name, identity)]
        audit = directory / 'calls.jsonl'
        if audit.is_file():
            audit_calls = add_original(audit)
            if audit_calls != case['calls']:
                raise ValueError('Aggregate predictions differ from the actual proxy audit bytes.')
        elif case['calls']:
            raise ValueError('Recorded calls have no original actual proxy audit.')
        events = directory / 'events.jsonl'
        actual_cli = verify_cli_receipts(case, case['calls'], events)
        usage = genuine_usage(case, events)
        if usage is not None:
            usages.append(usage)
        actual_finishes = []
        for index, call in enumerate(case['calls']):
            wire = call['response']
            result = wire.get('result', {})
            failed = bool(wire.get('error') or result.get('isError'))
            mcp_error_calls += int(failed)
            if call['tool'] == 'finish_investigation' and not failed:
                actual_finishes.append(result.get('structuredContent'))
            if call['tool'] not in ('query_incident', 'get_trace'):
                continue
            record = result.get('structuredContent') or {}
            metadata = record.get('metadata') or {}
            timings = (result.get('_meta') or {}).get('io.github.startreedata/mcp-pinot') or {}
            native = metadata.get('native_stats') or {}
            entry = {'case_id': identity, 'call_index': index, 'tool': call['tool'], 'kind': call.get('args', {}).get('kind'), 'request_id': metadata.get('request_id'), 'failed': failed, 'native_timeUsedMs': native.get('timeUsedMs', 'UNKNOWN'), 'mcp_execution_ms': timings.get('execution_ms', 'UNKNOWN'), 'proxy_elapsed_ms': call.get('elapsed_ms', 'UNKNOWN')}
            sql_ledger.append(entry)
            if finite(native.get('timeUsedMs')):
                native_times.append(native['timeUsedMs'])
            if finite(timings.get('execution_ms')):
                mcp_times.append(timings['execution_ms'])
            if finite(call.get('elapsed_ms')):
                proxy_times.append(call['elapsed_ms'])
        actual = actual_finishes[-1] if actual_finishes else None
        timing = case.get('timing', {})
        for field in timed_values:
            if finite(timing.get(field)):
                timed_values[field].append(timing[field])
        host_metadata = verify_host_metadata(case, directory)
        ledger.append({
            'host_metadata': host_metadata, 'host_telemetry_error': case.get('host_telemetry_error'),
            'host_diagnostic_timing_ms': {field: case.get(field, 'UNKNOWN') for field in _DIAGNOSTIC_TIMINGS},
            'case_id': identity, 'expected_status': expected[identity]['status'],
            'summary_status': case['status'], 'actual_raw_status': actual.get('status') if actual else None,
            'raw_matches_truth': outcome(actual) == outcome(expected[identity]) if actual else False,
            'verified_finish': case['verified_finish'], 'qualification': case['qualification'],
            'elapsed_ms': case['elapsed_ms'], 'exit_code': case.get('exit_code', 'UNKNOWN'),
            'timed_out': case.get('timed_out', 'UNKNOWN'), 'cli_issues': case.get('cli_issues', []),
            'cli_warnings': case.get('cli_warnings', []), 'usage_receipt_present': usage is not None,
            'actual_usage': usage if usage is not None else 'UNKNOWN',
            'observed_model': case.get('observed_model', 'UNKNOWN'), 'error': case.get('error'),
            'timing': timing, 'initial_collection': collection_observations(case['calls']),
            'cli_receipt_validation_recomputed': actual_cli,
            'cli_events_present': events.is_file(), 'proxy_audit_present': audit.is_file(),
        })
    field_counts = {field: sum(type(usage.get(field)) is int and usage[field] >= 0 for usage in usages) for field in TOKEN_FIELDS}
    recorded = {field: sum(usage[field] for usage in usages if type(usage.get(field)) is int and usage[field] >= 0) for field in TOKEN_FIELDS}
    complete_usage = len(usages) == len(ledger)
    return {
        'full_original_score': report,
        'cases': ledger,
        'actual_raw_matches': sum(case['raw_matches_truth'] for case in ledger),
        'successful_raw_finishes': sum(case['actual_raw_status'] is not None for case in ledger),
        'timeouts': sum(case['timed_out'] is True for case in ledger),
        'case_errors': sum(bool(case['error']) for case in ledger),
        'cases_with_cli_issues': sum(bool(case['cli_issues']) for case in ledger),
        'mcp_error_calls': mcp_error_calls,
        'actual_query_tool_call_count': len(sql_ledger),
        'native_sql_submissions_with_metadata': sum(bool(entry['request_id']) for entry in sql_ledger),
        'native_query_ledger': sql_ledger,
        'evidence_timing_ms': {'native_timeUsedMs': stats(native_times), 'mcp_execution': stats(mcp_times), 'proxy_elapsed': stats(proxy_times)},
        'case_timing_ms': {field: stats(values) for field, values in timed_values.items()},
        'usage_receipt_count': len(usages), 'usage_receipts_complete': complete_usage,
        'aggregate_usage': {field: recorded[field] if field_counts[field] == len(ledger) else 'UNKNOWN' for field in TOKEN_FIELDS} if complete_usage else 'UNKNOWN',
        'recorded_usage_subset': {'scope': 'Available actual receipts only; partial subtotal is not the full-arm total.', 'receipt_count': len(usages), 'field_receipt_counts': field_counts, 'totals': recorded},
        'usage_relationships': 'cached input is a subset of input; reasoning output is a subset of output; do not add subsets to totals',
        'host_metadata_summary': {'present': sum(case['host_metadata']['present'] for case in ledger), 'errors': sum(bool(case['host_telemetry_error']) for case in ledger), 'host_selected_model_counts': dict(Counter(case['host_metadata']['host_selected_model'] for case in ledger)), 'host_selected_effort_counts': dict(Counter(case['host_metadata']['host_selected_effort'] for case in ledger)), 'host_selected_provider_counts': dict(Counter(case['host_metadata']['host_selected_provider'] for case in ledger)), 'archived_and_preserved': sum(case['host_metadata'].get('archived') is True and case['host_metadata'].get('archived_bytes_preserved') is True for case in ledger), 'provider_attested_model': 'UNKNOWN', 'billing': 'UNKNOWN'},
        'host_diagnostic_timing_ms': {field: stats([case['host_diagnostic_timing_ms'][field] for case in ledger if finite(case['host_diagnostic_timing_ms'][field])]) for field in _DIAGNOSTIC_TIMINGS},
        'actual_model_identity': 'UNKNOWN unless explicitly supplied by a provider receipt',
        'cost_usd': 'UNKNOWN',
        'initial_observation_order_matches': sum(case['initial_collection']['matches_requested_initial_order'] for case in ledger),
        'initial_sequential_nonoverlap_observed': sum(case['initial_collection']['sequential_nonoverlap_observed'] is True for case in ledger),
        'onset_query_count': sum(case['initial_collection']['onset_query_count'] for case in ledger),
    }



def available_paired_usage(pairs, arm_summaries):
    usages = {arm: {case['case_id']: case['actual_usage'] for case in summary['cases']} for arm, summary in arm_summaries.items()}
    identities = [pair['case_id'] for pair in pairs if all(isinstance(usages[arm][pair['case_id']], dict) for arm in ('default', 'planned'))]
    totals = {}
    for arm in ('default', 'planned'):
        recorded = [usages[arm][identity] for identity in identities]
        cached_known = bool(recorded) and all(type(usage.get('cached_input_tokens')) is int and 0 <= usage['cached_input_tokens'] <= usage['input_tokens'] for usage in recorded)
        totals[arm] = {
            'input_tokens': sum(usage['input_tokens'] for usage in recorded) if recorded else 'UNKNOWN',
            'cached_input_tokens': sum(usage['cached_input_tokens'] for usage in recorded) if cached_known else 'UNKNOWN',
            'uncached_input_tokens': sum(usage['input_tokens'] - usage['cached_input_tokens'] for usage in recorded) if cached_known else 'UNKNOWN',
            'output_tokens': sum(usage['output_tokens'] for usage in recorded) if recorded else 'UNKNOWN',
        }
    return {
        'scope': (f"All {len(identities)}/{len(pairs)} normal receipt pairs, full normal comparison coverage; injected probes excluded and billing unknown." if len(identities) == len(pairs) else f"Available {len(identities)}/{len(pairs)} actual receipt pairs only; this partial subset is not the full-trial token total or cost."),
        'availability_rule': 'Include a case only when both arms have actual completed CLI usage receipts; no filtering by outcome, success, or latency.',
        'receipt_pair_count': len(identities),
        'full_trial_pair_count': len(pairs),
        'case_ids': identities,
        'excluded_by_receipt_availability_case_ids': [pair['case_id'] for pair in pairs if pair['case_id'] not in identities],
        'per_arm_tokens_for_same_available_ids': totals,
        'planned_over_default_input_token_ratio': totals['planned']['input_tokens'] / totals['default']['input_tokens'] if identities and totals['default']['input_tokens'] > 0 else 'UNKNOWN',
        'quality_and_latency_denominator': 'All original 18 pairs, including timeout/error cases, remain in the quality and latency comparison.',
        'cost_usd': 'UNKNOWN',
    }


def main():
    if DESTINATION.exists() and any((DESTINATION / name).exists() for name in ('receipts.tar.gz', 'results.json')):
        raise ValueError('Refusing to overwrite sealed owned-host evidence.')
    runtime = document(SOURCE / 'runtime.json')
    failed_report = document(BACKUP / 'host-timeout-probe.json')
    original_driver = document(SOURCE / 'temporary-driver.json')
    validate_closed_normal_runtime(runtime, failed_report, original_driver)
    if snapshot(BACKUP / 'runtime.json') != snapshot(SOURCE / 'runtime.json'):
        raise ValueError('The original failed combined runtime was rewritten.')
    if runtime.get('git', {}).get('dirty') is not False or not re.fullmatch(r'[0-9a-f]{40}', runtime.get('git', {}).get('head', '')):
        raise ValueError('Require an exact clean source commit at trial launch.')
    if runtime.get('fixture_suite') != 'extended' or runtime.get('collection_strategy') != 'counterbalanced_paired' or runtime.get('host_telemetry') is not True:
        raise ValueError('Require the six-template extended paired suite.')
    if type(runtime.get('native_exit_code')) is not int or type(runtime.get('owned_pid')) is not int:
        raise ValueError('Require a stopped owned native process receipt.')
    require_stopped(runtime['owned_pid'])
    sys.path.insert(0, str(ROOT))
    from examples.incident_replay.live import source_hashes
    if source_hashes(ROOT) != runtime['source_sha256']:
        raise ValueError('Current source differs from the completed frozen trial.')
    # No private truth is read until all completion and source gates above pass.
    truth = add_original(SOURCE / 'truth.json')
    expected = cases(truth)
    if len(expected) != 18:
        raise ValueError('Require all 18 private outcomes, including failed predictions.')
    for filename in ('runtime.json', 'probes.json', 'comparison.json'):
        add_original(SOURCE / filename)
    receipt = add_original(SOURCE / 'dataset/receipt.json')
    if [seed['seed'] for seed in receipt['seeds']] != [450, 451, 452]:
        raise ValueError('Require exactly fresh seeds 450, 451 and 452.')
    locations = {}
    comparison_documents = []
    public_ids = []
    seed_truth = []
    arm_predictions = {arm: [] for arm in ('default', 'planned')}
    for seed_index, seed in enumerate(receipt['seeds']):
        seed_name = 'seed_' + str(seed['seed'])
        seed_directory = SOURCE / 'dataset' / seed_name
        public = add_original(seed_directory / 'public.json')
        private = add_original(seed_directory / 'truth.json')
        if len(cases(public)) != 6 or len(cases(private)) != 6:
            raise ValueError('Each original seed must contain all six cases.')
        for filename in ('public.json', 'truth.json'):
            if digest(snapshot(seed_directory / filename)) != seed['sha256'][filename]:
                raise ValueError('Original fixture scope is not bound to its receipt.')
        if {case['case_id']: case for case in public['cases']} != {case['case_id']: case['public_scope'] for case in private['cases']}:
            raise ValueError('Private truth scopes differ from original public alerts.')
        public_ids += [case['case_id'] for case in public['cases']]
        seed_truth += private['cases']
        parity = add_original(SOURCE / (seed_name + '-parity.json'))
        if parity.get('full_row_parity') is not True or parity.get('source_rows') != seed['rows'] or parity.get('native_rows') != seed['rows'] or parity.get('source_sha256') != parity.get('native_sha256'):
            raise ValueError('Full-row parity does not bind all original fixture rows.')
        comparison = add_original(SOURCE / seed_name / 'model/comparison.json')
        comparison_documents.append(comparison)
        if comparison.get('public_sha256') != digest(snapshot(seed_directory / 'public.json')) or comparison.get('settings', {}).get('mode') != 'model':
            raise ValueError('Per-seed comparison does not bind its public case bytes.')
        if comparison.get('settings', {}).get('planned_first') is not bool(seed_index % 2):
            raise ValueError('Seed-order counterbalancing differs from requested trial.')
        for index, case in enumerate(public['cases']):
            expected_order = ['planned', 'default'] if bool(index % 2) ^ bool(seed_index % 2) else ['default', 'planned']
            if comparison['cases'][index] != {'case_id': case['case_id'], 'order': expected_order}:
                raise ValueError('Case-order counterbalancing differs from original plan.')
            for arm in ('default', 'planned'):
                locations[(arm, case['case_id'])] = SOURCE / seed_name / 'model' / arm / str(index)
        for arm in ('default', 'planned'):
            original = add_original(SOURCE / seed_name / 'model' / arm / 'predictions.json')
            if original.get('mode') != 'model' or [case['case_id'] for case in original['cases']] != [case['case_id'] for case in public['cases']]:
                raise ValueError('Per-seed arm predictions omit or reorder public cases.')
            arm_predictions[arm] += original['cases']
    if len(set(public_ids)) != 18 or set(public_ids) != set(expected) or seed_truth != truth['cases']:
        raise ValueError('Aggregate truth does not contain every original public case exactly once.')
    if document(SOURCE / 'comparison.json') != {'seeds': comparison_documents}:
        raise ValueError('Aggregate comparison differs from its original per-seed documents.')
    for comparison in comparison_documents:
        settings = comparison['settings']
        if settings.get('timeout_seconds') != 60 or settings.get('cli_defaults') is not True or settings.get('configured_selection') != {} or settings.get('host_telemetry') is not True:
            raise ValueError('Comparison changed the unchanged 60-second CLI-default selection controls.')
    summaries = {}
    predictions_by_arm = {}
    for arm in ('default', 'planned'):
        predictions_path = SOURCE / ('model_' + arm + '-predictions.json')
        score_path = SOURCE / ('model_' + arm + '-score.json')
        predictions = add_original(predictions_path)
        report = add_original(score_path)
        if predictions['cases'] != arm_predictions[arm] or set(cases(predictions)) != set(expected) or report.get('case_count') != 18:
            raise ValueError('Aggregate arm omits or changes original prediction cases.')
        verify_score(report, predictions, truth, predictions_path, SOURCE / 'truth.json')
        summaries[arm] = mode_summary(arm, predictions, report, expected, locations)
        predictions_by_arm[arm] = cases(predictions)
    pairs = []
    for identity in public_ids:
        default = predictions_by_arm['default'][identity]
        planned = predictions_by_arm['planned'][identity]
        comparison_case = next(case for comparison in comparison_documents for case in comparison['cases'] if case['case_id'] == identity)
        d_usage = next(case['actual_usage'] for case in summaries['default']['cases'] if case['case_id'] == identity)
        p_usage = next(case['actual_usage'] for case in summaries['planned']['cases'] if case['case_id'] == identity)
        pairs.append({'case_id': identity, 'order': comparison_case['order'], 'default_elapsed_ms': default['elapsed_ms'], 'planned_elapsed_ms': planned['elapsed_ms'], 'planned_minus_default_ms': planned['elapsed_ms'] - default['elapsed_ms'], 'planned_over_default_latency_ratio': planned['elapsed_ms'] / default['elapsed_ms'] if default['elapsed_ms'] > 0 else 'UNKNOWN', 'default_verified_finish': default['verified_finish'], 'planned_verified_finish': planned['verified_finish'], 'default_error': default.get('error'), 'planned_error': planned.get('error'), 'planned_over_default_input_token_ratio': p_usage['input_tokens'] / d_usage['input_tokens'] if isinstance(d_usage, dict) and isinstance(p_usage, dict) and d_usage['input_tokens'] > 0 else 'UNKNOWN'})
    d_latencies = [pair['default_elapsed_ms'] for pair in pairs]
    p_latencies = [pair['planned_elapsed_ms'] for pair in pairs]
    complete_tokens = all(summaries[arm]['usage_receipts_complete'] for arm in summaries)
    d_tokens = summaries['default']['aggregate_usage']
    p_tokens = summaries['planned']['aggregate_usage']
    paired = {
        'case_count': len(pairs), 'inclusion': 'All 18 original paired cases, including timeouts/errors; no success-only filtering.',
        'order_counts': dict(Counter(' -> '.join(pair['order']) for pair in pairs)),
        'cases': pairs,
        'planned_minus_default_ms': signed_stats([pair['planned_minus_default_ms'] for pair in pairs]),
        'default_raw_latency_ms': stats(d_latencies), 'planned_raw_latency_ms': stats(p_latencies),
        'planned_over_default_sum_latency_ratio': sum(p_latencies) / sum(d_latencies),
        'planned_over_default_median_latency_ratio': statistics.median(p_latencies) / statistics.median(d_latencies),
        'median_within_pair_latency_ratio': statistics.median([pair['planned_over_default_latency_ratio'] for pair in pairs]) if all(finite(pair['planned_over_default_latency_ratio']) for pair in pairs) else 'UNKNOWN',
        'planned_over_default_total_input_token_ratio': p_tokens['input_tokens'] / d_tokens['input_tokens'] if complete_tokens and d_tokens['input_tokens'] > 0 else 'UNKNOWN',
        'median_within_pair_input_token_ratio': statistics.median([pair['planned_over_default_input_token_ratio'] for pair in pairs]) if complete_tokens and all(finite(pair['planned_over_default_input_token_ratio']) for pair in pairs) else 'UNKNOWN',
        'token_ratio_receipts_complete': complete_tokens,
        'available_paired_usage': available_paired_usage(pairs, summaries),
        'interpretation': 'Observed local paired comparison; host-selected model is recorded separately. Provider-attested execution identity, billing, provider conditions and wider population effects remain unknown.',
    }
    preliminary = seal_preliminary_probe()
    timeout_diagnostics = seal_failed_timeout_probe(runtime)
    drivers = seal_temporary_drivers()
    corrected_timeout = seal_corrected_timeout_probe(runtime['source_sha256'])
    derivation = normal_derivation_receipt(runtime, failed_report, drivers)
    installed_cli = add_original(INSTALLED_CLI_OBSERVATION, prefix='installed-cli-observation', source=INSTALLED_CLI_OBSERVATION.parent)
    if installed_cli.get('executable') != comparison_documents[0]['settings'].get('codex'):
        raise ValueError('Post-run installed CLI observation differs from the recorded driver path.')
    FILES['NORMAL-ARMS-DERIVATION.json'] = (json.dumps(derivation, indent=2, allow_nan=False) + '\n').encode()
    FILES['CLI-LINEAGE.json'] = (json.dumps(LINEAGE, indent=2) + '\n').encode()
    manifest = {name: {'sha256': digest(data), 'bytes': len(data)} for name, data in sorted(FILES.items())}
    manifest_bytes = (json.dumps(manifest, indent=2) + '\n').encode()
    FILES['MANIFEST.json'] = manifest_bytes
    for name in FILES:
        path = PurePosixPath(name)
        if path.is_absolute() or '..' in path.parts or '\\' in name or ':' in name or str(path) != name:
            raise ValueError('Unsafe archive member path.')
    archive_buffer = io.BytesIO()
    with gzip.GzipFile(filename='', fileobj=archive_buffer, mode='wb', mtime=0) as compressed, tarfile.open(fileobj=compressed, mode='w') as archive:
        for name, data in sorted(FILES.items()):
            entry = tarfile.TarInfo(name)
            entry.size, entry.mtime, entry.mode = len(data), 0, 0o644
            archive.addfile(entry, io.BytesIO(data))
    archive_bytes = archive_buffer.getvalue()
    with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode='r:gz') as archive:
        if {member.name for member in archive.getmembers()} != set(FILES) or any(not member.isfile() for member in archive.getmembers()):
            raise ValueError('Archive member validation failed.')
        for member in archive.getmembers():
            if archive.extractfile(member).read() != FILES[member.name]:
                raise ValueError('Archived bytes differ from original or filtered bytes.')
    results = {
        'schema_version': 1,
        'scope': 'Six synthetic templates, seeds 450-452; 18 paired cases per arm. Production RCA, takeover and full-cost savings remain unproven.',
        'normal_arms_source_trial': TRIAL, 'runtime_commit': runtime['git'],
        'original_combined_run': {'evaluation_complete': False, 'evaluation_valid': False, 'failure': runtime['failure'], 'runtime_sha256': digest(snapshot(SOURCE / 'runtime.json'))},
        'normal_arms_derivation': derivation,
        'source_unchanged': runtime['source_unchanged'], 'clean_initial_source': True,
        'cli_selection': 'Unchanged cli_defaults selection; host-selected model/provider/effort are diagnostic observations, provider-attested model and billing remain UNKNOWN.',
        'requested_cli_features': {'default': {'code_mode_host': 'enabled', 'code_mode': 'not explicitly enabled'}, 'planned': {'code_mode_host': 'enabled', 'code_mode': 'enabled'}},
        'code_mode_execution_claim': 'Requested planned collection is distinguished by CLI config and prompt; actual MCP order/gaps are observed, while an outer execution-block receipt is unavailable.',
        'arms': summaries, 'paired': paired,
        'preliminary_owned_probe': preliminary,
        'intentional_host_timeout_probe': timeout_diagnostics,
        'corrected_host_timeout_probe': corrected_timeout,
        'post_run_installed_cli_observation': installed_cli,
        'temporary_execution_drivers': drivers,
        'archive': {'file': 'receipts.tar.gz', 'sha256': digest(archive_bytes), 'bytes': len(archive_bytes), 'members': len(FILES), 'manifest_sha256': digest(manifest_bytes)},
        'publication_filter': 'Original completed JSON/audit bytes, byte-identical allowlisted CLI thread/MCP/usage/error lines, already-filtered owned host metadata, and hashed temporary driver sources. No raw rollout files, reasoning, agent/user messages, auth content, stderr, native data or workspaces are exported; synthetic SQL rows remain.',
        'runtime_completed_at': runtime['stopped_at'],
    }
    privacy_check(results)
    # Verify source files stayed unchanged throughout collection/export construction.
    if any(path.read_bytes() != data for path, data in SNAPSHOTS.items()):
        raise ValueError('An original receipt changed while constructing its immutable export.')
    if source_hashes(ROOT) != runtime['source_sha256']:
        raise ValueError('Sources changed during evidence export construction.')
    DESTINATION.mkdir(parents=True, exist_ok=True)
    with (DESTINATION / 'receipts.tar.gz').open('xb') as target:
        target.write(archive_bytes)
    with (DESTINATION / 'results.json').open('x') as target:
        target.write(json.dumps(results, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'archive_bytes': len(archive_bytes), 'members': len(FILES), 'archive_sha256': digest(archive_bytes), 'results': str(DESTINATION / 'results.json')}))


def synthetic_rejection_tests():
    """Exercise new derivation gates with synthetic data; never run the exporter."""
    from copy import deepcopy
    import tempfile
    import unittest

    class DerivationGates(unittest.TestCase):
        def setUp(self):
            self.hashes = {'synthetic.py': 'a' * 64}
            self.runtime = {
                'evaluation_complete': False, 'evaluation_valid': False,
                'failure': deepcopy(EXPECTED_FAILURE), 'source_unchanged': True,
                'stopped_at': '2026-10-09T04:21:31+00:00', 'source_drift': [],
                'source_sha256': self.hashes, 'source_sha256_end': self.hashes,
                'git': {'head': SOURCE_COMMIT, 'dirty': False}, 'native_exit_code': -9,
            }
            self.failed = {
                'probe_complete': True, 'all_passed': False,
                'checks': {key: key != 'owned_delayed_children_stopped' for key in FAILED_PROBE_CHECKS},
                'source_unchanged': True, 'source_sha256': self.hashes,
                'source_sha256_end': self.hashes, 'git': self.runtime['git'],
                'started_at': '2026-10-09T04:20:44+00:00',
            }
            self.driver = {
                'git_before': self.runtime['git'], 'source_unchanged': True,
                'source_sha256_before': self.hashes, 'source_sha256_end': self.hashes,
                'timeout_probe_invocations': 1,
                'run_settings': {'start_seed': 450, 'seeds': 3, 'extended_cases': True, 'mode': 'model', 'compare_collection': True, 'host_telemetry': True, 'cli_defaults': True, 'model_deadline_seconds': 60},
            }

        def test_only_exact_failed_runtime_is_derivable_without_mutation(self):
            original = deepcopy(self.runtime)
            validate_closed_normal_runtime(self.runtime, self.failed, self.driver)
            self.assertEqual(self.runtime, original)
            for field, value in (
                ('evaluation_complete', True), ('evaluation_valid', True),
                ('failure', {'error_type': 'OtherError', 'detail': 'unrelated failure'}),
                ('stopped_at', None), ('source_unchanged', False),
                ('source_sha256_end', {'synthetic.py': 'b' * 64}),
                ('git', {'head': SOURCE_COMMIT, 'dirty': True}),
            ):
                altered = deepcopy(self.runtime)
                altered[field] = value
                with self.subTest(field=field), self.assertRaises(ValueError):
                    validate_closed_normal_runtime(altered, self.failed, self.driver)

        def test_extra_or_missing_fault_failures_cannot_be_laundered(self):
            for mode in ('extra_failure', 'missing_check', 'unknown_check', 'promoted_success'):
                altered = deepcopy(self.failed)
                if mode == 'extra_failure':
                    altered['checks']['no_fabricated_finish'] = False
                elif mode == 'missing_check':
                    altered['checks'].pop('no_fabricated_finish')
                elif mode == 'unknown_check':
                    altered['checks']['another_check'] = True
                else:
                    altered['all_passed'] = True
                with self.subTest(mode=mode), self.assertRaises(ValueError):
                    validate_closed_normal_runtime(self.runtime, altered, self.driver)

        def test_driver_reselection_source_drift_and_reruns_are_rejected(self):
            for mode in ('reselection', 'source_drift', 'rerun', 'boolean_count'):
                altered = deepcopy(self.driver)
                if mode == 'reselection':
                    altered['run_settings']['model_deadline_seconds'] = 61
                elif mode == 'source_drift':
                    altered['source_sha256_end'] = {'synthetic.py': 'b' * 64}
                else:
                    altered['timeout_probe_invocations'] = 2 if mode == 'rerun' else True
                with self.subTest(mode=mode), self.assertRaises(ValueError):
                    validate_closed_normal_runtime(self.runtime, self.failed, altered)

        def test_late_failure_must_preserve_the_actual_original_prefix(self):
            prefix = [{'tool': 'begin_investigation', 'response': {}}]
            late = {'tool': 'query_incident', 'args': {'kind': 'baseline'}, 'response': {'error': {'message': 'synthetic failure'}}, 'started_ms': 70800, 'completed_ms': 70810}
            before = {'forwarded_to_original_driver': False, 'forwarded_at': None, 'received_at': '2026-10-09T04:20:55+00:00'}
            after = {**before, 'forwarded_to_original_driver': True, 'forwarded_at': '2026-10-09T04:21:55+00:00'}
            validate_late_failure_audit(prefix, [*prefix, late], before, after, 30)
            for calls in ([late], [*prefix, {**late, 'started_ms': 1}], [*prefix, {**late, 'response': {}}]):
                with self.assertRaises(ValueError):
                    validate_late_failure_audit(prefix, calls, before, after, 30)
            with self.assertRaises(ValueError):
                validate_late_failure_audit(prefix, [*prefix, late], before, before, 30)

        def test_modified_inputs_and_after_fault_scores_are_rejected(self):
            global SOURCE, BACKUP, SNAPSHOTS
            original = SOURCE, BACKUP, SNAPSHOTS
            try:
                with tempfile.TemporaryDirectory(prefix='derived-gate-test-') as directory:
                    SOURCE, BACKUP = Path(directory) / 'source', Path(directory) / 'backup'
                    SOURCE.mkdir()
                    BACKUP.mkdir()
                    SNAPSHOTS = {}
                    for name in ('model_default-score.json', 'model_planned-score.json'):
                        for base in (SOURCE, BACKUP):
                            (base / name).write_text('{}\n')
                            os.utime(base / name, ns=(1_000_000_000, 1_000_000_000))
                        snapshot(SOURCE / name)
                    drivers = {'temporary_driver_sha256': {}}
                    receipt = normal_derivation_receipt(self.runtime, self.failed, drivers)
                    self.assertFalse(receipt['original_combined_evaluation_valid'])
                    (BACKUP / 'model_default-score.json').write_text('{"altered":true}\n')
                    SNAPSHOTS.pop(BACKUP / 'model_default-score.json')
                    with self.assertRaises(ValueError):
                        normal_derivation_receipt(self.runtime, self.failed, drivers)
                    (BACKUP / 'model_default-score.json').write_text('{}\n')
                    SNAPSHOTS.pop(BACKUP / 'model_default-score.json')
                    os.utime(SOURCE / 'model_default-score.json', ns=(2_000_000_000_000_000_000, 2_000_000_000_000_000_000))
                    with self.assertRaises(ValueError):
                        normal_derivation_receipt(self.runtime, self.failed, drivers)
            finally:
                SOURCE, BACKUP, SNAPSHOTS = original

        def test_timeout_cannot_mint_completed_usage_or_a_finish(self):
            prediction = {'timed_out': True, 'verified_finish': False, 'model_usage': 'UNKNOWN', 'raw_finish': None}
            report = {'prediction': prediction, 'excluded_from_model_accuracy': True, 'excluded_from_collection_comparison': True, 'host_deadline_seconds': 30, 'injected_baseline_delay_seconds': 60}
            validate_timeout_prediction(report, prediction)
            for field, value in (('verified_finish', True), ('model_usage', {'input_tokens': 1}), ('raw_finish', {}), ('provider_receipt', {})):
                altered = {**prediction, field: value}
                with self.subTest(field=field), self.assertRaises(ValueError):
                    validate_timeout_prediction({**report, 'prediction': altered}, altered)

    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(DerivationGates))
    if not result.wasSuccessful():
        raise SystemExit(1)


if __name__ == '__main__':
    if sys.argv[1:] == ['--self-test']:
        synthetic_rejection_tests()
    elif sys.argv[1:]:
        raise ValueError('Only --self-test is accepted; sealing uses the reviewed fixed paths.')
    else:
        main()
