"""Run the standard paired replay, then one separately recorded host-timeout probe."""

import argparse
import asyncio
from datetime import UTC, datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Users/xiangfu/.codex/worktrees/6789/mcp-pinot-incidents')
sys.path.insert(0, str(ROOT))
from examples.incident_replay import live, runner

JAVA = '/Library/Java/JavaVirtualMachines/temurin-25.jdk/Contents/Home/bin/java'
JAR = Path('/Users/xiangfu/.m2/repository/org/apache/pinot/pinot-distribution/1.5.1/pinot-distribution-1.5.1-shaded.jar')
DELAY_PROXY = Path('/tmp/incident_delayed_query_proxy.py')
HOST_DEADLINE_SECONDS = 30
INJECTED_DELAY_SECONDS = 60


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def read_process_status(pid):
    # Read only a PID directly recorded by the owned fault-probe child.
    result = subprocess.run(['ps', '-p', str(pid), '-o', 'stat='], capture_output=True, text=True, shell=False, timeout=5)
    state = result.stdout.strip()
    return {'pid': pid, 'state': state or 'absent', 'running': bool(state) and not state.startswith('Z')}


def timeout_probe(output, dataset, broker, controller, driver_receipt):
    directory = output / 'host-timeout-probe'
    directory.mkdir()
    public = json.loads((dataset / 'public.json').read_text())
    case = public['cases'][0]
    model_args = argparse.Namespace(
        dataset=dataset, broker=broker, controller=controller, codex=runner.executable_path('codex', program='codex'),
        cli_defaults=True, timeout=HOST_DEADLINE_SECONDS, mode='model', planned_collection=True, host_telemetry=True,
    )
    modifications = []
    original_popen = runner.subprocess.Popen
    original_driver = str(ROOT / 'examples/incident_replay/model.py')

    def intercepted_popen(argv, *popen_args, **popen_kwargs):
        if isinstance(argv, list) and len(argv) > 1 and Path(argv[0]).name == 'codex' and argv[1] == 'exec':
            prefix = 'mcp_servers.incident_reader.args='
            positions = [index for index, argument in enumerate(argv) if isinstance(argument, str) and argument.startswith(prefix)]
            if len(positions) != 1:
                raise ValueError('Expected one original incident_reader args configuration.')
            index = positions[0]
            original_value = json.loads(argv[index][len(prefix):])
            if not isinstance(original_value, list) or not original_value or original_value[0] != original_driver:
                raise ValueError('Expected the original literal model.py proxy path.')
            replacement_value = [str(DELAY_PROXY), *original_value[1:]]
            changed = list(argv)
            changed[index] = prefix + json.dumps(replacement_value)
            modifications.append({
                'scope': 'only this intentional deadline probe',
                'changed_config_key': 'mcp_servers.incident_reader.args',
                'original_driver': original_driver,
                'replacement_driver': str(DELAY_PROXY),
                'original_config_value_sha256': hashlib.sha256(argv[index].encode()).hexdigest(),
                'replacement_config_value_sha256': hashlib.sha256(changed[index].encode()).hexdigest(),
                'remaining_proxy_arguments_identical': original_value[1:] == replacement_value[1:],
                'all_other_cli_arguments_identical': all(before == after for position, (before, after) in enumerate(zip(argv, changed)) if position != index),
            })
            return original_popen(changed, *popen_args, **popen_kwargs)
        return original_popen(argv, *popen_args, **popen_kwargs)

    report = {
        'schema_version': 1,
        'scope': 'one intentional host-deadline fault probe; excluded from paired quality/latency/token totals',
        'excluded_from_model_accuracy': True,
        'excluded_from_collection_comparison': True,
        'case_id': case['case_id'],
        'dataset_seed': 450,
        'host_deadline_seconds': HOST_DEADLINE_SECONDS,
        'injected_baseline_delay_seconds': INJECTED_DELAY_SECONDS,
        'started_at': datetime.now(UTC).isoformat(),
        'source_sha256': live.source_hashes(ROOT),
        'git': live.git_identity(ROOT),
        'temporary_drivers': driver_receipt['temporary_drivers'],
        'probe_complete': False,
        'all_passed': False,
    }
    destination = output / 'host-timeout-probe.json'
    write(destination, report)
    runner.subprocess.Popen = intercepted_popen
    try:
        prediction = asyncio.run(runner._prediction(model_args, case, directory / '0'))
    finally:
        runner.subprocess.Popen = original_popen
    # Preserve the real prediction first, before checking expected fault semantics.
    write(directory / 'prediction.json', prediction)
    report['prediction'] = prediction
    report['actual_interception_count'] = len(modifications)
    report['cli_invocation_changes'] = modifications
    marker_path = directory / '0' / 'delayed-baseline-request.json'
    proxy_runtime_path = directory / '0' / 'delayed-proxy-runtime.json'
    marker = json.loads(marker_path.read_text()) if marker_path.is_file() else None
    proxy_runtime = json.loads(proxy_runtime_path.read_text()) if proxy_runtime_path.is_file() else None
    report['delayed_baseline_request'] = marker or 'NOT_OBSERVED'
    report['delayed_proxy_runtime'] = proxy_runtime or 'NOT_OBSERVED'
    telemetry = prediction.get('host_telemetry', {})
    usage = telemetry.get('token_usage', {})
    latest = usage.get('latest_total', {})
    positive_partial = isinstance(latest, dict) and isinstance(latest.get('input_tokens'), int) and latest['input_tokens'] > 0 and isinstance(latest.get('output_tokens'), int) and latest['output_tokens'] > 0
    checks = {
        'exactly_one_config_interception': len(modifications) == 1 and modifications[0]['all_other_cli_arguments_identical'] and modifications[0]['remaining_proxy_arguments_identical'],
        'actual_baseline_held_without_forwarding': isinstance(marker, dict) and marker.get('forwarded_to_original_driver') is False,
        'baseline_not_admitted_as_native_sql': not any(call.get('tool') == 'query_incident' and call.get('args', {}).get('kind') == 'baseline' for call in prediction.get('calls', [])),
        'actual_host_deadline_observed': prediction.get('timed_out') is True,
        'original_finish_not_verified': prediction.get('verified_finish') is False,
        'no_fabricated_finish': prediction.get('raw_finish') is None,
        'completed_cli_usage_remains_unknown': prediction.get('model_usage') == 'UNKNOWN',
        'no_completed_provider_receipt': 'provider_receipt' not in prediction,
        'owned_partial_snapshot_observed': positive_partial and usage.get('snapshot_count', 0) > 0,
        'partial_snapshot_not_complete_usage': usage.get('complete') is False,
        'no_completed_turn_claim': telemetry.get('completion', {}).get('cli_completed_turn_observed') is False,
        'owned_session_archived_and_preserved': prediction.get('host_session_archived') is True and prediction.get('host_session_bytes_preserved') is True,
        'owned_proxy_group_inherited': isinstance(proxy_runtime, dict) and proxy_runtime.get('inherited_process_group') is True,
    }
    if isinstance(proxy_runtime, dict):
        states = [read_process_status(proxy_runtime[key]) for key in ('proxy_pid', 'model_proxy_pid')]
        report['owned_child_process_states'] = states
        checks['owned_delayed_children_stopped'] = all(not state['running'] for state in states)
    report['checks'] = checks
    report['source_sha256_end'] = live.source_hashes(ROOT)
    report['source_unchanged'] = report['source_sha256_end'] == report['source_sha256']
    report['probe_complete'] = True
    report['all_passed'] = all(checks.values()) and report['source_unchanged']
    report['finished_at'] = datetime.now(UTC).isoformat()
    write(destination, report)
    print(json.dumps({'stage': 'intentional_host_timeout_probe', 'probe_complete': True, 'all_passed': report['all_passed'], 'checks': checks}), flush=True)
    if not report['all_passed']:
        raise RuntimeError('Intentional host-timeout probe failed; retained original artifacts, no rerun.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    if not output.is_relative_to(ROOT / 'examples/incident_replay/output'):
        parser.error('Use an ignored owned replay output path.')
    if output.exists():
        parser.error('The output path must be new; previous runs are preserved.')
    driver_receipt = {
        'scope': 'temporary orchestration wrapper; standard paired replay plus separate actual host-timeout fault probe',
        'temporary_drivers': {
            str(path): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in (Path(__file__).resolve(), DELAY_PROXY)
        },
        'source_sha256_before': live.source_hashes(ROOT),
        'git_before': live.git_identity(ROOT),
        'run_settings': {'start_seed': 450, 'seeds': 3, 'extended_cases': True, 'mode': 'model', 'compare_collection': True, 'host_telemetry': True, 'cli_defaults': True, 'model_deadline_seconds': 60},
        'timeout_probe_invocations': 0,
    }
    original_run_script = live.run_script

    def run_script(name, *arguments):
        # All standard dataset, load, model and score subprocesses are untouched.
        original_run_script(name, *arguments)
        if name != 'probes.py':
            return
        if driver_receipt['timeout_probe_invocations'] != 0:
            raise RuntimeError('The separate intentional timeout probe must run once.')
        for arm in ('model_default', 'model_planned'):
            if not (output / f'{arm}-score.json').is_file():
                raise RuntimeError('Both original paired arms must be scored before the fault probe.')
        if arguments.count('--dataset') != 1 or arguments.count('--output') != 1:
            raise ValueError('Unexpected original fault-probe invocation shape.')
        dataset = Path(arguments[arguments.index('--dataset') + 1])
        original_probes_path = Path(arguments[arguments.index('--output') + 1])
        original_bytes = original_probes_path.read_bytes()
        original_probes = json.loads(original_bytes)
        driver_receipt['original_probes'] = {'path': str(original_probes_path), 'sha256': hashlib.sha256(original_bytes).hexdigest(), 'check_count': len(original_probes.get('checks', [])), 'all_passed': original_probes.get('all_passed')}
        driver_receipt['timeout_probe_invocations'] += 1
        write(output / 'temporary-driver.json', driver_receipt)
        if original_probes.get('all_passed') is not True or len(original_probes.get('checks', [])) != 6:
            raise RuntimeError('The six original fault probes did not all pass; retaining their original report.')
        timeout_probe(output, dataset, 'http://127.0.0.1:8000', 'http://127.0.0.1:9000', driver_receipt)
        if original_probes_path.read_bytes() != original_bytes:
            raise RuntimeError('Original six fault-probe report changed.')

    original_argv = sys.argv
    live.run_script = run_script
    sys.argv = [str(ROOT / 'examples/incident_replay/live.py'), '--jar', str(JAR), '--java', JAVA, '--output', str(output), '--seeds', '3', '--start-seed', '450', '--mode', 'model', '--timeout', '60', '--cli-defaults', '--extended-cases', '--compare-collection', '--host-telemetry']
    try:
        live.main()
    finally:
        sys.argv = original_argv
        live.run_script = original_run_script
        if output.is_dir():
            driver_receipt['source_sha256_end'] = live.source_hashes(ROOT)
            driver_receipt['source_unchanged'] = driver_receipt['source_sha256_end'] == driver_receipt['source_sha256_before']
            driver_receipt['finished_at'] = datetime.now(UTC).isoformat()
            write(output / 'temporary-driver.json', driver_receipt)


if __name__ == '__main__':
    main()
